# ZoeW — deep audit និង hardening checkpoint

**ស្ថានភាព៖ FINAL AGGREGATE RUNNING — មិនទាន់អះអាង full PASS។** នេះជារបាយការណ៍ checkpoint លើ local patch បន្ទាប់ពីការពិនិត្យឥរិយាបថ user branch។ Initial strict aggregate មាន **208 PASS / 7 FAIL / 0 SKIP** លើ tree `575c304db7e1e5aa`; វាមិនមែនលទ្ធផលចុងក្រោយនៃ source បច្ចុប្បន្នទេ។ Current frozen commit `27f00719aa59645b1b74d083d3ac7da0019113f5` remotely verified; source SHA256 `dd071fa1904b00bc6e4f2b3edd310a4450064f1c176fe91c40481a6f961ff21f`។ Fresh `verification-*` run កំពុងដំណើរការ; performance/CI នៅ pending។

**HIGH residual៖** unknown scan → restart អាចទុក ledger និង registry មិនស្រប history។ A454 រក្សាភស្តុតាងមុន effect និង warning ក្រោយ restart; compensation/release ordering កែរួច តែ **full automatic financial reconciliation នៅ PARTIAL** ដោយខ្វះ authoritative retained receipt/registry ownership។ មិនទាយ reversal។ Pickup race ដើមបានកែជា A456 ដោយ revision/reset epoch នៅ authoritative boundary និង rules; actual Firebase5/5 និង Postgres4/4 focused proof ឆ្លង។ Crash after history commit before durable permission នៅ HOLD; final aggregate/CI នៅ pending។

## មូលដ្ឋាន និងការរក្សាការងារម្ចាស់

- Remote target `claude/affectionate-cray-ua2chn`; base SHA **`b0a67e915e61e6b8c8e4bc06a435c86742e45fa0`**; checkout `/workspace/Zoe-System-target`, local branch `codex/deep-audit-target-20261029`។ WIP43ad59f0 និង resumed checkpoint `27f00719aa59645b1b74d083d3ac7da0019113f5` បាន non-force push និង verify remote; source tree ស្អាតពេល freeze។ User base remote នៅដដែល។
- ZoeW base **2.50.175 / zoew-v439** → local **2.50.176 / zoew-v440**។ ZoeKeyGen base **2.24.30 / zoekeygen-v141** → local **2.24.31 / zoekeygen-v142** ព្រោះ validator/rules compatibility កែទាំងពីរ Apps។ Version checks ចុងក្រោយនៅ pending។
- User target មាន **11 commits / 135 changed paths** លើស main `d74c6021da8a16c3db03d0c4d541e19dd77fa989`។ អាន diff និងតាម execution paths A417–A444 ពិត; មិនត្រឹមផ្ទៀង preservation។ `branch-behavior-map.json/md` ភ្ជាប់ path → commit → intent/flow → risk → tests/evidence → status។
- Original main checkout/evidence `/workspace/Zoe-System` និង `/workspace/zoe-audit-20261029` រក្សាដាច់ដោយឡែក; main-only PASS មិនរាប់ជាភស្តុតាង target។ `target-commits.txt`, `target-vs-main.txt`, `instruction-delta.txt`, `overlap-review.md` កត់មូលដ្ឋាន។ Related-PR status គឺ snapshot ពេល lookup; ត្រូវ recheck មុន publication។
- គ្មាន AGENTS.md ឬ checkout `.agents/skills` ដែលបានរកឃើញ។ អនុវត្ត CLAUDE/HISTORY និង relevant cloud-runtime/Supabase skills។ ការប្រែ metadata និងប្រវត្តិមិនលុប A417–A444។
- **សិទ្ធិបច្ចុប្បន្ន៖** local audit/code/tests/docs និង commit, non-force push, draft PR ត្រូវបានអនុញ្ញាតក្រោយ verification/overlap gate តាមសារ 2026-10-29 01:47:45 UTC។ **Merge, PR approval, deployment, production DB/rules/secrets changes និង real ZTO mutations មិនត្រូវបានអនុញ្ញាត។** Read-only Git fetch/PR lookup បានធ្វើ; គ្មាន production mutation ក្នុងការវាស់នេះ។ Publication ដែល parent ធ្វើក្រោយ checkpoint ត្រូវកត់ជាមួយលទ្ធផលពិត។

## ផែនទី និង source of truth

```mermaid
flowchart LR
  UI[React UI / scan / reminder] --> Domain[Domain operation]
  Domain --> J[Durable journals / operation identity]
  Domain --> Adapter[fb adapter selected by Config]
  Adapter --> F[Firebase RTDB]
  Adapter --> S[Supabase RPC / RLS]
  F --> Truth[Committed rows / ledger / receipts]
  S --> Truth
  Truth --> Sync[Owned listeners / delta pull / recovery]
  Sync --> UI
  Z[Netlify ZTO bridge] --> Evidence[Signed / unsigned / unknown evidence]
  Evidence --> Domain
```

Firebase និង Supabase ជា **backend ជម្រើស**; គ្មាន automatic dual-write។ Backend switch ប្ដូរ adapter/session ownership មិនផ្ទេរ DB ដោយស្វ័យប្រវត្តិ។ ZTO និង business DB មិនមាន distributed transaction រួម។ Diagram មិនអះអាងថា every business effect មាន durable journal គ្រប់គ្រាន់ទេ៖ scan reboot gap ខាងលើជាករណីខ្វះ។

| Entity | Authority / conflict policy | ព្រំដែន |
|---|---|---|
| Barcode/history/trash | backend row, registry, CAS claims/tokens | optimistic UI/queue មិនមែន commit proof |
| Money | actual daily/monthly applied receipts និង keyed ledger events | birth/lifecycle mismatch មិនអាចបកស្រាយថា original save failed; retention មិនមែន permanent audit ledger |
| Pickup/customer/package | exact barcode ownership set និង phone refs | distinct picked-up phone owners និង counted barcode keys; revision/Reset epoch CAS និង authoritative rules fence, unresolved permission នៅ HOLD |
| Restore | source claim, target witness/provenance, atomic finalize | observed Signed blocks restore; unobserved upstream Sign មិនអាចអះអាងបាន |
| Supabase cursor/quota | `zoe_tenant_state`, `zoe_docs`, dedup `zoe_ops` | tenant lock/SQL transaction tested locally; managed service transport/auth មិនបានវាស់ |
| License seat | server slot ceiling + current `releaseEpoch`; admin release marker | concurrency fence មិនមែន cryptographic client identity; public key-ID seat model ដើមរក្សា |
| ZTO evidence | validated upstream response persisted as final markers | local close ≠ Sign; timeout/auth/malformed/stale ≠ unsigned |

Baseline inventory៖ **1,117 tracked files, 25 authored Markdown, 35 migrations**។ Structural inventory មាន functions/callbacks, screens, listeners, jobs, APIs, storage និង rules; វាមិនមែន function-by-function behavioral proof។ Patch បន្ថែម migrations ពីរ (សរុប 37) និង tests/helpers; `scan-evidence.ts`, `scan-pending.ts`, `scan-evidence.test.ts` នៅក្នុង A454 durable evidence scope; focused tests ឆ្លង តែ final aggregate pending។ `final-file-coverage-map.json` កត់ source additions និង pending status ច្បាស់។

## Finding register និងការកែ

| ID / HISTORY | Severity / status | Root cause → local change / evidence |
|---|---|---|
| M-01 / A445 | HIGH · local fix | shared localStorage journal ប៉ុន្តែ live claim set ក្នុង tab ផ្ទាល់ ➜ document ownership, Web Locks, v2 journal; baseline race RED និង browser/VM controls |
| M-02 / A445 | MEDIUM · local fix | storage boolean បាត់ ➜ DB action ចាប់ផ្ដើមមុន durable journal; awaited start និង refusal gates |
| B1/B2 / A446 | HIGH · local fix | console `seq=head+1` mistaken internal; conflict insert counted twice ➜ internal-origin fence + tenant-serialized actual-write accounting; real PostgreSQL probes |
| NOTIFY-SIGNED-1 / A447 | MEDIUM · local fix | signed/open row ចូល reminder ➜ canonical signed predicate; actual drawer/schedule ACK tests |
| C-01 / A448 | MEDIUM · local fix | exit0 without executed fresh assertions ➜ Vitest JSON freshness/count/status validation; empty/skip/todo controls |
| AUTH-HIDDEN-1 / A449 | LOW · local fix | hidden recovery listener outlives owner ➜ subscription-owned disposal;30cycles |
| C-02 / A450 | MEDIUM evidence integrity · local fix | losing20s deadline timer kept process alive past meta budget ➜ clear in finally; actual runner103PASS27.571s, poisoned runner103intentionalFAIL/exit1 in27.487s; deadline unchanged |
| Fixture compatibility / A450 | test correction · focused PASS | awaited claim-start exposes old async fixtures; topic fixture lacked SDK identity ➜ original invariants retained, lifecycle settling/source extraction corrected;95cleanup PASS,30restore-marker PASS + negative control |
| Ledger companion ABA / A451 | HIGH · local fix | direct lookup ignored `createdAt` although copy search checked it ➜ exact birth guard; native/Supabase RED controls and actual authenticated Postgres6/6PASS |
| Palm candidate completeness / A452 | MEDIUM · local fix | sibling `candidatePage` retained short/empty/count gaps after signed-list fix ➜ conservative count/read-on checks; baseline29PASS2FAIL → focused190PASS; no live ZTO mutation |
| License release race / A453 | HIGH · local fix | seller release after fresh GET before seat PUT ➜ old client reclaims slot; epoch equality enforced in rules, bounded reread, persisted acknowledged epoch;79client/116rules PASS, negative controls1+4 FAIL |
| Scan outcome ambiguity / A454 | HIGH · bounded hardening / PARTIAL recovery | per-operation durable evidence before effects, timestamped mismatch HOLD, confirmed compensation before registry release; focused139 PASS. Automatic reboot finance repair not implemented; do not call end-to-end repaired. |
| BM-07 scan reboot residual | HIGH · OPEN/PENDING A454 | actual native wrapper recovery drains refused data journal while applied ledger and registry remain;1executedFAIL,12filteredSKIP; full correction requires durable business-operation ownership |
| BM-08 / A456 pickup replay | HIGH · focused fix / aggregate pending | daily revision/epoch CAS with server rules, original Reset context, post-commit history permission, durable per-entry journal and pending UI; Firebase5PASS, actual adapter/PG4PASS, rules111PASS. Known old Reset cancels pickup only; unknown/legacy HOLD. |
| A455 late import | HIGH · focused fix | late timeout callback closed replacement lifecycle; confirmed outcome + captured lifecycle identity prevents stale closure; RED1FAIL retained. |
| A456 cleanup storage | HIGH · focused fix | old-reader erasure, array RMW and repeated updater duplicate entries; isolated v2 per-entry keys, stable captured operationID/timestamp and actor/scope; independent9PASS. |
| DOC-T1/T2 | LOW · corrected prose | actual ACTION_REGISTRY boundary, Firebase/Sentry CDN loading conditions, concise entrypoint and License epoch rollout; final docscope/index checks pending |

Full file references, reproduction and residual limits៖ `money.md`, `backend.md`, `network.md`, `checkers.md`, `branch-behavior-{money,backend,network,auth,keygen,checkers}.md/json`។ New defects are reproduced synthetic/local cases; report does not assert production loss or live credential leakage.

## តារាងស្ថានភាព និង daily matrix

Delete preserves **ledger amounts/revenue totalCount**; it does not freeze every active UI/customer/package count. Remove reverses actual applied value once. Allowed restore credits only the original applied receipt once. Close is local status; Sign requires ZTO evidence. Prepared restore stays pending until finalize; terminal cancellation removes only inserted provenance and does not credit.

| Backend × mode | delete → restore | remove → restore | pickup2h → restore | abandon8d → restore |
|---|---|---|---|---|
| Firebase × Simple/Sheet | allowed | allowed + receipt credit | allowed | applicable terminal rules |
| Firebase × Cookie | fresh unsigned allowed; signed denied | same + receipt | unsigned allowed; signed denied | returned/terminal exception per code |
| Firebase × Palm | existing blanket denial | existing blanket denial | verified Sign cleanup; restore denied | existing denial |
| Supabase × Simple/Sheet | allowed | allowed + receipt credit | allowed | applicable terminal rules |
| Supabase × Cookie | fresh unsigned allowed; signed denied | same + receipt | unsigned allowed; signed denied | returned/terminal exception per code |
| Supabase × Palm | existing blanket denial | existing blanket denial | verified Sign cleanup; restore denied | existing denial |

This is **policy interpretation**, not a final test result. Palm unsigned-delete/remove restore policy still needs a separate business decision; existing code remains unchanged. That policy question is distinct from the technical scan/pickup recovery defects. Sheet Sign cases are **not applicable**, never counted PASS.

Completed initial-tree matrix uses actual Firebase SDK/rules/emulator and actual Supabase adapter/RPC/RLS over local PostgreSQL; auth/HTTP/realtime upstream and ZTO are synthetic. Two backend checkers PASS with **20 top-level assertions,200 scenario groups,714 DB checkpoints**; these units must not be added. Firebase3contexts/3seed sequences×12rounds; Supabase2shops×3contexts,6rounds and1442`zoe_write` requests. Supabase deterministic matrix acts on shop0 and checks shop1 unchanged357times.

`requested-scenario-matrix.json` retains **24 rows ×19fault classes =456 coverage cells** on initial tree:88observedPASS/248PARTIAL/120NOT RUN. These are coverage classifications, not test counts. Current patch validation is separately pending; completed page-close cases do not cover arbitrary process death, A454 business recovery or every opposing race. Signed-denied restore has no write boundary at which to inject a restore-side network failure.

## Invariants និង negative controls

- Independent money oracle uses scripted fixture deltas and backend dumps, not the mutation function. Daily/monthly receipt effects, count, barcode uniqueness, registry ownership and pickup sets are checked at each converged stage; intermediate writes are not all separately serialized.
- Matrix example: Firebase Sheet Remove `245.07/40/count20` → `235.07/38/19` → allowed Restore `245.07/40/20`; Delete `195.07/30/15` remains unchanged through move/restore. Recomputed590standard-flow checkpoints match independent `(COD10,DOD2,count1)` deltas.
- Pickup/customer values were asserted by oracle but initial successful logs do not dump every numeric before/after value; that evidence remains **PARTIAL**. Revenue count is not customer count or picked-up package count.
- A451 actual PostgreSQL: reused lifecycle would wrongly apply `40→45` or undo `45→40`; corrected results preserve40/45. Same-life/legacy positive controls still apply expected+5. Evidence `backend-companion-aba-pg-{red,green}.json`.
- **OPEN scan reboot witness:** day/month amount/count `10/1` → unknown `15/2`; after reboot still`15/2`, history packages1, registryheld, journal0. Expected recovery`10/1` and registryabsent. Actual scan-action/native recovery wrapper with synthetic SDK/server; no real-emulator claim. `scan-native-reboot-witness.json`.
- **Pre-fix pickup witness (now regression):** foreign close commits package/customer`1/1`; stale replay produces`0/0` while history remainsclosed. Ledger stays`100/10/count10`; baseline empty→new and same-value ABA fail. Corrected actual Firebase/PG probes preserve the foreign key and original Reset outcome; source hashes are recorded in `resume-pickup-protocol.md` and `resume-pickup-client-pg-frozen-inputs.json`. `pickup-gap-witness-{false,true}.json`.
- Initial money guardian18mutations caught18; A453 server-fence removal produces4intentionalFAIL and before-mine guard removal1intentionalFAIL; C-02 exact poisoned runner exits1 under original60s budget. Controls and filtered SKIP remain separate from product PASS.
- No exactly-once network-delivery claim. Current business-effect claims apply only within recorded tested scenarios; the unresolved red cases explicitly prevent a blanket monetary-invariant guarantee.

## Coverage, evidence និងស្ថានភាព

**Final aggregate: RUNNING on27f00719; CI: PENDING draft PR.** Initial immutable snapshot `raw/checker-initial-full-state.tsv` is208PASS/7FAIL/0SKIP. Fixed focused tests do not rewrite those results. Current source additions and A454 are marked pending in module/scenario coverage.

| Scope | Completed bounded evidence | Limit / next gate |
|---|---|---|
| Deep user-branch review | all135paths mapped;86already-correct bounded,25residual/fix,24partial/unverified | path counts are not bug/test counts; new findings can be FIXED or OPEN/HOLD |
| Money initial/targeted |406focusedPASS +48seeded scenarios; later11files199PASS; latest ledger/scan55PASS | overlap;55tests include conservative HOLD, not the unresolved reboot/pickup reproductions |
| Real backend matrix |2checkers PASS,20topassertions,714checkpoints | initial tree only; latest full matrix pending |
| Auth/network/reminders |388focusedPASS/29files; auth24PASS; strengthened regression6PASS | local SDK/happy-dom/Chromium fixtures; device/provider lifecycle unavailable |
| Supabase datastore/RLS/migration |222+491assertions; compatibility7PASS | real local Postgres with synthetic auth/HTTP; no production repair |
| A451 lifecycle guard |native21PASS; Supabase29PASS; actual Postgres6PASS | focused suites overlap; scan operation recovery remains independent |
| A452 ZTO candidate guard |190focusedPASS; original29PASS2RED | enumerated synthetic page shapes; no live dataset/page drift |
| A453 License |79clientPASS;116actualrulesPASS;11actual-client/emulator control cases | rules-first rollout; no managed/production deployment |
| License adjacent / setup crypto |41grace+25clock+35rollback+140record-race PASS;50setup/secret PASS/3files | clock fixture correction recorded; final production artifact gate pending |
| C-01/C-02 |fresh-report controls13VM+5realVitest; diagnostics6PASS; actual runner103PASS and poison103FAIL | full meta rerun remains pending |
| Recovery residuals | scan reboot financial mismatch remains; durable evidence/explicitHOLD verified. Pickup original race now real-backend focused green | full aggregate pending; crash-before-permission and legacy remainHOLD |
| Docs/secret survey |25authoredMD/221locallinks/0missing;363reachableGittextblobs +1081currenttextfiles | heuristic/static snapshot; no guaranteed absence of secrets or full historical prose verification |
| LiveZTO/realphones/production scale |NOT RUN | no production mutations or live Sign requested/performed |

No sum of overlapping focused/full runs is presented as unique total. Initial setup/environment failures, deliberately red regressions, superseded main evidence and current product failures are retained separately. `final-file-coverage-map.json` uses PARTIAL for whole modules, with bounded execution evidence attached rather than blanket PASS.

## Performance និង capacity

Environment: Linux x86_64,5reportedCPUs, Node24.19.0, Chromium154, PostgreSQL17.10, RTDBemulator4.11.2, proxy networking. Production configurations/secrets were not inspected or used.

Completed target probe **single samples**, under concurrent lab load:8000-key CAS1680ms;20000-barcode document write446ms/read64ms;~12MB pull2pages, slowest882ms;>8MiB write-boundary refusal asserted. Matrix checker durations Firebase272.097s/Supabase256.997s include setup; they are not per-operation latency. Measured lifecycle loops returned active listener count to baseline.

Per-action p50/p95/p99, error-rate denominator, steady-state memory/CPU/read-write cost and final-patch sync-convergence distribution are **NOT RUN/PENDING** at this checkpoint; instrument scripts do not count as execution. No measured production capacity is claimed. A proposed lab SLO could target zero invariant violations, online commit p95≤2s/p99≤5s and convergence≤10s for a fixed declared workload; these are **proposal targets, not measurements or production guarantees**, and require the timed run before adoption.

## Rollout / rollback / prerequisites

1. Commit/non-force push/draft PR authorization does not grant merge/deploy/rules-publish authority. Final verification, exact SHA/content manifest and remote-tip/overlap recheck remain gates. Current HIGH OPEN risks must remain prominent in any review artifact; no release-readiness claim while A454 is unresolved.
2. **License rules FIRST, then both clients.** A433`releasedAt` already belonged to the user branch; A453 adds`releaseEpoch` write-boundary fencing. Old rules reject the new client field. New rules preserve never-released legacy claims and immutable-device/at metadata on existing pre-epoch seats; old clients must update before activating/reclaiming released Keys. Explicit fresh activation and same-second Date-header cases are tested. No production publish occurred.
3. License rollback is not a delete-marker workaround. Rolling clients back leaves released-key activation incompatible; rolling rules back reopens the race and rejects new-client fields. Prefer a reviewed forward repair. Never erase release markers/seat data to conceal failure. Public key-ID seat access remains an existing design boundary.
4. Supabase append-only `20261029010711_zoe_console_write_origin.sql` preserves signatures/data/ACL;37migrations in the tested local upgraded chain after pickup rules migration `20261029222313_zoe_rules.sql`. Proposed rollback `backend-rollback-proposed.sql` was sandbox-tested and reopens B1/B2. Do not delete applied migrations. This patch prevents future corruption; it does not repair historical production seq/bytes. Any production investigation/repair needs separate approved scope.
5. Existing user rollout remains: replace old6-digit lookup links with16-character links; update ZoeW APK/PWA before sending`#setup=` links; update ZoeKeyGen and site ZTO Function together when deployment is authorized. Existing encrypted configured APIs remain; do not rewrite A417–A444 history as if these prerequisites were new audit discoveries.
6. Finish pending writes before normal app update; do not clear journals/site data or force reload. v2claim journal protects new claims from old readers; old-old clients keep old risk. Without Web Locks, conservative recovery can wait until24hlease expiry. Client rollback keeps journals and requires pending-claim review.
7. **Business rules FIRST, then ZoeW.** Firebase uses root `firebase-database.rules.json`; Supabase uses ordered migrations36console-origin then37pickup-rules. Test upgrade in staging with synthetic data; no production application authorized. Preserve fences/metadata/journals and a protocol-aware client on rollback; old clients cannot mutate promoted days. A454 durable evidence preserves unresolved outcomes; no automatic production financial reconciliation is proposed.

## Remaining risks និងការសម្រេច

- **HIGH technical PARTIAL:** scan reboot ledger/registry divergence is preserved as pending evidence, not automatically reconciled. Actual retained delta receipts and owned registry are prerequisites for safe automatic repair. Pickup stale deletion/ABA has focused real-backend proof; crash-after-history-before-permission and legacy journals stay HOLD. These evidence/contract gaps are not solved by choosing a business rule.
- **Business-policy BLOCKED:** whether Palm unsigned manual Delete/Remove trash should restore, rather than blanket denial. Existing policy preserved; behavioral tests do not settle requested policy intent.
- Existing A352 scale/push/receipt limits, S5`p_replace` and X6member-management limitations remain scoped and unclaimed. Cookie shops with no open entries may not refresh returned-trash evidence through the hourly sweep.
- Already accepted signed push schedules may remain stale until10min minimum gap plus a successful refresh; offline can extend this. Persisted evidence cannot attest an unobserved upstream event.
- New pickup/cleanup journals use per-entry keys with stable operation identity and Web Lock admission; legacy v1 stays untouched and old clients cannot mutate promoted pickup days. Browser storage loss/clearing can still lose local evidence; no cross-device backup of journals is claimed. No-lock/mixed-version and unknown permission HOLD deliberately reduce availability.
- Authenticated business users can directly edit monetary aggregates by accepted design. No immutable permanent audit ledger or new trusted-server aggregate recomputation was introduced.
- Managed-service auth/Realtime, actual push provider, production configs/credential revocation, remote CI artifacts/telemetry/browser caches, real iPhone/Android/APK behavior, SW upgrade with unsynced writes and production-scale sustained load remain unverified.

## Reproduce និង deliverables

Exact base SHA is above. Current repository is frozen and clean at27f00719; `preservation-resumed.json` verifies remote and `WIP-27f00719.bundle` is validated. Aggregate/CI, measurements and archive manifest are still pending. Do not use a pre-fix CI badge as final proof.

- Full strict runner/settings: `run-verification.py --fingerprint`, then `--run --expected-source-sha256 <frozen digest>`; `run-final.py`/`final-run-settings.json` belong only to initial evidence. Initial evidence remains under`raw-final/` and immutable state snapshot; late fixes do not overwrite its meaning.
- Focused License: `LICSEAT_APP_DIR=/workspace/zoe-audit-target-20261029/license-current-fixture node audit-tools/license-seat-test.js`; `LICSEATEMU_APP_DIR=/workspace/Zoe-System-target node audit-tools/emu/license-seat-rules-test.js` from target root. The fixture points at current validators; its clock-bridge artifact provenance is recorded in`license-a453-adjacent-results.json`.
- Focused ledger/HOLD: from`ZoeW`, `./node_modules/.bin/vitest run tests/scan-save-unknown.test.ts tests/ledger-replay-companion.test.ts tests/supabase-ledger-replay-companion.test.ts --maxWorkers=1 --reporter=json --outputFile=/tmp/money-aba.json`.
- Unresolved RED controls: commands/config paths in`branch-behavior-money.md` and`durable-scan-design.md`; filtered cases are SKIP. They are evidence of the unresolved boundary, not the final A454 verdict.
- Coverage/inventory: `system-inventory.json`, `inventory.md`, `branch-behavior-map.json/md`, `final-file-coverage-map.json`, `requested-scenario-matrix.json`, `matrix-evidence.json/md`, `secret-survey.json`, `markdown-survey.json`.
- A concise external review summary is prepared for the PR body or existing HISTORY appendix, avoiding redundant dated history files; parent owns that integration and publication gate. Detailed workspace artifacts remain available for handoff. No guarantee of “no bugs”, “100% safe” or arbitrary scale is made.


## Resumed checkpoint and conservative recovery runbook

Recovery first verified all74 modified and6 untracked files in the same worktree. WIP43ad59f0 includes81files and is remotely verified; local validated `WIP-43ad59f0.bundle` is an additional recovery artifact. Subsequent checkpoint/final commit IDs are recorded separately. No clean/reset/reconstruction from memory occurred. The temporary repository checkpoint document was folded into HISTORY and remains recoverable from WIP.

For unknown scan evidence: preserve the original browser storage and operationID, inspect only the current backend/tenant/account via `scan-pending-export-console.js` (read-only allowlisted export). Export is diagnostic evidence, never authority to replay or reverse money. Compare original history lifecycle, per-bucket applied receipts and registry ownership under a separately reviewed recovery action; when proof is missing, keep HOLD. Do not clear site data, retry under another account, delete registry keys or infer reversal from absence. No automatic repair/deployment is performed by this audit.

Current source review: compensation release only follows proven inverse; late imports require confirmed outcome/captured birth; SDK updater callbacks remain speculative; cleanup retried updaters share stable operation identity; foreign scope/account retains byte-identical evidence and releases only old in-memory owners. Focused figures overlap and cannot be summed as a whole-tree pass. Actual rules111PASS, browser5PASS, PostgreSQL4PASS and independent storage9PASS are bounded regression evidence, not production capacity or all-state guarantees.
