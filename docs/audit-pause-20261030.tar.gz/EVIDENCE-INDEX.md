# Evidence navigation

Start with `AUDIT-REPORT.md` for current conclusions. Individual agent reports and RED/intermediate outputs are historical, scoped snapshots; they do not supersede the current report or establish a final aggregate pass. Main-only results live in a separate directory and are not included as target evidence.

- Verified target: `claude/affectionate-cray-ua2chn` at `b0a67e915e61e6b8c8e4bc06a435c86742e45fa0`.
- First preserved work: remoteWIP `43ad59f00a93441fb95636e61375a19a689005be`.
- Resumed source checkpoint: remoteWIP `27f00719aa59645b1b74d083d3ac7da0019113f5`; `preservation-resumed.json`, validated `WIP-27f00719.bundle`.
- Frozen source digest: `dd071fa1904b00bc6e4f2b3edd310a4450064f1c176fe91c40481a6f961ff21f`; `verification-source-before.json` records all paths and orchestration inputs. Runner's own shorter tree digest uses a different algorithm.
- Current full run: `verification-*`, `logs/verification-run-all.log`, `raw-verification/`, `numeric-verification/`. Only `verification-exit.json` can establish its completed result; absence means unfinished.
- Earlier aggregate: `final-*`, `raw-final/`, 208PASS/7FAIL. These remain unchanged and cannot be reported as the current source's result.
- Independent behavior/overlap: `review-final-gate.json`, `overlap-review.md`, `branch-behavior-independent.md`, `branch-behavior-map.json`, per-domain behavior reports. The135paths are not135tests; bounded review and unverified areas are explicit.
- Recovery/pickup: `durable-scan-design.md`, `branch-behavior-money.md`, `money-source-frozen.json`, `resume-pickup-protocol.md`, `resume-pickup-protocol-rules.md`, `resume-pickup-client-pg-frozen.json`, `review-cleanup-storage-frozen.json`, `root-collected-v2-verification.json`.
- Checker truthfulness: `protocol-fixture-final-checkpoint.md`, `journal-observer-checkpoint.md`, `review-crud-fixture-final.md`, raw RED/mutation files. Expected mutation failures and filtered tests are not product failures or PASS counts.
- Inventory/security/docs: `inventory-final-checkpoint.md`, `final-file-coverage-map.json`, `secret-survey.json`, `artifact-secret-survey.json`, `markdown-survey.json`. Secret recognizers are bounded heuristics, not proof of universal absence/revocation.
- Performance: `verification-load-plan.md`, measured logs and JSON only after they exist. Prepared scripts alone are NOT RUN. HTTP/GUI distributions and synthetic transport limits must remain separate from production capacity.

Reproduction uses Node24.19.0, Chromium154 and local RTDB/PostgreSQL. Source `/workspace/zoe-cloud/env.sh`, then append the local-only `node-loopback-faye.cjs` preload for Node Firebase tests. Never copy production credentials into fixtures. See actual per-report commands; source-root checkers and generated measure-root checkers have different contracts.

Bundle recovery (only when needed, in a new worktree): verify the bundle and prerequisite base first, then fetch its HEAD into a new local recovery branch. Never reset/clean the existing worktree or overwrite the user's source branch. The remote audit branch remains the preferred code backup.

Unknown scan money/history outcomes retain evidence and warnings; no automatic financial repair is claimed. Legacy and crash-before-permission pickup journals stay HOLD. No merge, production rules/schema deployment, live ZTO mutation or blanket safety/capacity guarantee is part of this evidence.
