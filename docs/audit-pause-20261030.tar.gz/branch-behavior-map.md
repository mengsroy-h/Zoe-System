# ផែនទីឥរិយាបថ user branch — 135 paths

Base `d74c6021da8a16c3db03d0c4d541e19dd77fa989` → user HEAD `b0a67e915e61e6b8c8e4bc06a435c86742e45fa0`: **11 commits / 135 paths**។ Current audit revision និង hashes នៅ [inventory-final-checkpoint.md](inventory-final-checkpoint.md) និង `branch-behavior-map.json`។

| Classification | Paths | Meaning |
|---|---:|---|
| already_correct | 86 | Direct bounded review/evidence for changed behavior; not whole-file proof. |
| new_residual | 25 | Newly reproduced residual or local correction/hardening; feature status distinguishes fixed/HOLD/partial. |
| unverified / PARTIAL | 24 | Prose, static-only or bounded feature evidence does not justify whole-path correctness. |

All135 paths have feature mapping; zero unmapped paths។ `new_residual` counts paths, not bugs។ Path ledger contains commits, feature IDs, execution review, risk, tests, evidence, source hashes and current verification state។ Overlapping reports/test assertions must not be added as independent counts។

Source reports: `branch-behavior-keygen`, `branch-behavior-money`, `branch-behavior-backend`, `branch-behavior-network`, `branch-behavior-auth`, `branch-behavior-checkers` (`.md`/`.json`)។ Later audit-added files are outside the original135 and mapped in `final-file-coverage-map.json`។

**PENDING FINAL VERIFICATION.** Initial aggregate208PASS7FAIL belongs to an earlier tree; current focused proof and real-backend tests cover only recorded scenarios. Full current scenario matrix, live ZTO, real devices and production capacity remain unverified. Durable scan pending evidence is not automatic financial reconciliation; legacy/unknown pickup permission remains HOLD.
