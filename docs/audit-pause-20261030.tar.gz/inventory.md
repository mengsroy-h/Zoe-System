> Current checkpoint: [inventory-final-checkpoint.md](inventory-final-checkpoint.md) records the resumed source, 37 migrations, refreshed links/secret survey and exact frozen SHA. Older counts below describe earlier audit phases.

> Authorization update, 2026-10-29 01:47:45 UTC: commit, non-force push and a draft PR from the dedicated audit branch into `claude/affectionate-cray-ua2chn` are now authorized after clean final verification and overlap review. Merge, PR approval, deployment and production mutations remain unauthorized. Earlier phase descriptions below record the restrictions at that time.

# Target audit៖ inventory · ឯកសារ · secrets · dead code

គោលដៅ៖ `claude/affectionate-cray-ua2chn` នៅ SHA **`b0a67e915e61e6b8c8e4bc06a435c86742e45fa0`**; checkout សម្រាប់ការកែ `/workspace/Zoe-System-target`។ មិនយកលទ្ធផលពី main មកប្រកាសថា target ជាប់ឡើយ។ Base `d74c6021da8a16c3db03d0c4d541e19dd77fa989` មាន **11 commits / 135 changed files** មកដល់ target។ `main` និងរបាយការណ៍ដើមនៅរក្សាដាច់។

## ការងារថ្មី និងការងារដែល target បានធ្វើរួច

- អាន target `CLAUDE.md` diff និង HISTORY **A417–A444** ព្រមទាំង changed active-doc diff។ A419 បានលុប CSS/types ស្លាប់ និងពិនិត្យ `runtime.ts` រួច; A420 បានកែព្រំដែន `ACTION_REGISTRY` ក្នុង CLAUDE។ A427/A428/A440 មានការកែ redaction, Setup Link fragment និងកូដ 16 តួរួច។ មិនបង្កើត finding ឬ patch ស្ទួនទេ។
- កែ `CLAUDE.md:3` ដាក់ **Start here** ខ្លីសម្រាប់ architecture, authority, recovery ownership, business invariants, commands និង authorization/evidence boundaries។ ព័ត៌មានលម្អិតដែល target បន្ថែមនៅរក្សាទាំងអស់។ ការបង្រួមឯកសារទាំងមូលនៅជា **PARTIAL** ដោយ guard ជាច្រើនចងនឹងច្បាប់លម្អិត; មិនបានធ្វើ rewrite ធំដែលបាត់ constraints។
- រកឃើញ residual documentation issue **DOC-T1 (Low)**៖ target A420 កែ CLAUDE ប៉ុន្តែ `ZoeW/docs/ARCHITECTURE.md:120` និង `ZoeW/docs/DEVELOPMENT.md:152` នៅអះអាងថា `ACTION_ALLOWLIST` ជាព្រំដែន App និងបាត់ឈ្មោះគ្រប់ករណីធ្វើឱ្យ build ធ្លាក់។ Code ពិត៖ `src/app/actions.ts:11` → `lookupAction()` ក្នុង `src/core/action-registry.ts:209` ពិនិត្យ key ក្នុង `ACTION_REGISTRY`; `name` ជា `string`, unknown ត្រូវ return ដោយមិនហៅ function។ `ACTION_ALLOWLIST` ក្នុង `core/runtime.ts` គឺ audit mirror។ បានកែ usage docs ទាំង 2 ឱ្យបែង TypeScript import validation, runtime name check និងតេស្តការភ្ជាប់ប៊ូតុង។ គ្មាន business code ប្រែដោយការកែ docs នេះ។
- មិនលុប dependency/source ដោយសន្មតថាមិនប្រើ។ មិនបានប៉ះ HISTORY/version ដែល parent គ្រប់គ្រង។ មិនបាន push, publish, deploy ឬកែ credential/production DB។

## ផែនទីពី code បច្ចុប្បន្ន

```text
index.html → main.tsx → App → bootApplication(scope)
  → React onAct → ACTION_REGISTRY / lookupAction
  → feature/domain → local state + durable journal/outbox
  → fb adapter ដែល Config ជ្រើស
      Firebase RTDB project
      OR Supabase SDK → tenant-scoped RPC/RLS → zoe_docs/zoe_ops
  → db-listeners / delta pull → store proxies → React UI

ZTO → Netlify zto-order-detail → Palm/Cookie upstream
  → validated verdict + observed timestamp → cleanup/restore policy
  → selected database → listener → UI
```

Firebase និង Supabase ជា **ជម្រើស backend**; គ្មាន automatic dual-write។ `firebase-init.ts` និង `supabase-config.ts` ជាផ្លូវជ្រើស។ Backend commit/receipts/ledger កំណត់លទ្ធផល; browser journals រក្សា intent មិនទាន់សម្រេច។ `isDeducted`, optimistic UI ឬ queue entry តែឯងមិនបញ្ជាក់ completion។ Target recovery បន្ថែម fresh history/trash evidence និង original-session ownership; បញ្ហាលុយ/race ត្រូវវាស់ដោយ money/backend agents ដាច់។

Firebase Business roots៖ history, trash, barcode registry, daily/monthly revenue, daily pickup/collected, settings, write receipts, restore/clear-history finalizations។ ZoeKeyGen License rules ដាច់ ហើយ target បន្ថែម `releasedAt` រួច។ Supabase business tables៖ `tenants`, `tenant_members`, `tenant_invites`, `member_devices`, `member_reset_codes`, `platform_admins`, `zoe_docs`, `zoe_ops`, `zoe_tenant_state`។ Auth/realtime bootstrap fixture SQL ក៏នៅក្នុង inventory ប៉ុន្តែមិនត្រូវរាប់ថាជា app migration ថ្មី។

Entry APIs៖ Netlify `health`, `push`, `push-cron`, `zto-order-detail`; Supabase `register`, `reset-password`; Apps Script `Code.gs`។ Local persistence មាន storage keys, cleanup/pickup/write journals, encrypted Lookup key និង Palm Sign IndexedDB outbox។ SW build គ្រប់គ្រង emitted shell; authenticated upstream data មិនត្រូវច្រឡំជាសំបក app។ Runtime resource/network/SW correctness ត្រូវមើល agent reports ផ្សេង។

## Inventory និង coverage

`system-inventory.json` អាន **tracked target files** ពិត ហើយប្រើ TypeScript AST សម្រាប់ declaration/import/call sites, SQL identifier patterns និង JSON rules។ ចំនួនខាងក្រោមគឺ static inventory មិនមែនចំនួន tests ឬ runtime active resources៖

| ប្រភេទ | ចំនួន |
|---|---:|
| tracked files | 1,117 |
| function/callback sites រួម source/tests/tools | 38,297 |
| static/dynamic import edges | 4,353 |
| listener registration/removal/subscription sites | 604 |
| timer/job sites | 790 |
| network call sites តាម category | 170 |
| storage call sites | 1,031 |
| literal storage identifiers | 64 |
| database-like call sites | 1,938 |
| SQL definitions រួម fixture SQL | 159 |
| migration files | 35 |
| Firebase rule clauses ទាំង Business/License | 270 |
| view/modal component files | 90 |
| checker/helper JavaScript files | 216 |
| authored Markdown | 25 |

`file-coverage-inventory.json` ភ្ជាប់រាល់ module → mapped guards → risk/limitation → inventory evidence → `STATIC_INVENTORIED`។ Mapping មិនជំនួស guard execution។ `system-inventory.json` ផ្ទុកទីតាំង line សម្រាប់រាល់ function/site; generated files និង dependencies install មិនមែន authored source។ Tests ថ្មីដែល agents បន្ថែមក្រោយ inventory ជា untracked មិនចូលលេខ 1,117 នេះទេ; parent final manifest និង final revision ជាប្រភពចុងក្រោយ។

## ឯកសារ និង dead-code evidence

- `markdown-survey.json` អាន authored Markdown **25** (active 23 + history 2) ពេញតាម scanner; local links **221**, missing targets **0**។ Semantic review ផ្តោតលើ rules, architecture, runbook, changed docs និង A417–A444; prose រាល់ប្រយោគក្នុង history/archive មិនបាន review ទាំងអស់៖ **PARTIAL**។ External link/deployed settings verification មិនបានរត់។
- `module-reachability.json`៖ `main.tsx` និង `sw.ts` import graph ឈានដល់ **255/258** TS source modules។ 3 ផ្សេងមានបរិបទប្រើពិត៖ `core/runtime.ts` audit mirror, `sw/cache-version.ts` Vite/build file read, `types/globals.d.ts` TypeScript include។ Target A419/A420 បានកត់រួច; មិនរកឃើញមូលហេតុថ្មីដើម្បីលុប។ Dynamic runtime registration/external entrypoints និង unused dependency/export review មិនអះអាងថាគ្រប់ទាំងអស់។
- គ្មាន `AGENTS.md` ឬ `.agents/skills` ដែលរកឃើញក្នុង checkout/parent workspace។ Target CLAUDE និង instructions ថ្មីត្រូវបានអនុវត្ត។
- `npm --prefix ZoeW run doc:check`៖ **6 claims PASS** លើ current parent version `2.50.176` (slots 28+7, version, README, package scripts 24 និង narrative constraints)។ `documentation-check.log` រក្សាភស្តុតាង។ CLAUDE 10-word duplicate-phrase rule៖ **0 violations**។
- `repository-file-coverage.js` ដំណាក់កាល agent៖ **9 PASS / 1 FAIL** ពី test ថ្មីមិនទាន់ mapped; parent គ្រប់គ្រង final mapping/rerun។ មិនមែន missing local-doc link ឬ broken integrity។ Dependency symlinks ជា runtime artifacts ត្រូវ parent exclude ក្នុង local git info; មិនចូល manifest។

## Secret survey លើ target

Baseline scan ដែលរក្សាដាច់បានអាន reachable local Git **1,457 commits / 12,981 blobs**, text blobs **12,929**។ វារួមគ្រប់ object ដែល reachable ពី base SHA `d74c6021`។

Target scan ថ្មីប្រើ៖

```bash
git rev-list --objects HEAD ^d74c6021da8a16c3db03d0c4d541e19dd77fa989
```

បាន scan **226 new reachable text blobs / 24,336,667 bytes** និង **current target tracked text files 1,072** ពេញឡើងវិញ។ Union របស់ base-reachable scan + target-minus-base គ្រប target reachable history; វាមិនមែនការយក old PASS មកសន្និដ្ឋានលើ changed files ទេ។ `secret-survey.json` កត់ exact SHA, scope command, baseline report path និង SHA-256 របស់ baseline report។

លទ្ធផល៖ **24 fingerprint groups**, **0 novel fingerprints** ធៀប baseline reviewed fixtures៖ synthetic/placeholder 7, test RSA key 1, redaction fixture 1, ZTO mock fixtures 15។ **0 confirmed live privileged leaks**; គ្មាន raw values ក្នុង report។ ការផ្ទៀង fixture មើលទីតាំង/context និង fingerprint; មិនសាក credential លើ live service ទេ។

Synthetic detection controls **4/4 PASS** (GitHub token, Supabase secret key, PEM private key, ZTO cookie); មិនជំនួស security-guard negative controls ពេញ។ Existing **target-local** artifact/log scan៖ **37 text files / 6,725,368 bytes**, candidate **0**។ Artifacts នេះនៅដំណាក់កាលក្រុមកំពុង build; final production build/security-guard ជារបស់ parent។

កម្រិត៖ pattern scan អាចខកខាន generic password, encoded/encrypted secret និង binary content។ Remote deleted refs, remote CI artifacts, production logs/Sentry, deployed environment variables និង real browser cache/storage **NOT RUN**។ Firebase public API config/Supabase anon key មិនស្មើ privileged credential។ គ្មានសេចក្តីអះអាងថា leak ទាំងអស់ត្រូវបានរកឃើញ ឬ credential ណាមួយ revoke រួច។

## Reproduce

```bash
node /workspace/zoe-audit-target-20261029/inventory.cjs
python3 /workspace/zoe-audit-target-20261029/survey-docs.py
python3 /workspace/zoe-audit-target-20261029/scan-history.py
python3 /workspace/zoe-audit-target-20261029/finalize-secret-survey.py
python3 /workspace/zoe-audit-target-20261029/scan-assets.py
cd /workspace/Zoe-System-target
npm --prefix ZoeW run doc:check
node audit-tools/repository-file-coverage.js
```

`finalize-secret-survey.py` ប្រើ baseline report ដែលបានពិនិត្យរួចតាម fingerprint; candidate ថ្មីទុកជា novel ដើម្បី review។ Scripts/report ទាំងនេះនៅ task workspace មិនមែន production bundle។ Publication/merge/deployment ត្រូវការសិទ្ធិដាច់; គ្មានសកម្មភាពនោះក្នុង subtask នេះ។
