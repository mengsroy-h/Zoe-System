'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const root = '/workspace/zoe-audit-target-20261029';
const revision = process.argv[2] || 'fixed';
const preload = path.join(root, revision === 'baseline' ? 'local-rpc-timing-preload-v1.cjs' : 'local-rpc-timing-preload.cjs');
const child = String.raw`
const assert = require('node:assert/strict');
const fs = require('node:fs');
const [preload, fault, desired] = process.argv.slice(1);
const entry = '/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root/audit-tools/supabase-money-multishop-test.js';
const output = '/workspace/zoe-audit-target-20261029/local-rpc-fault-' + fault + '-' + process.pid + '.json';
const read = fs.readFileSync, write = fs.writeFileSync;
process.argv[1] = fault === 'guard-io' ? '/tmp/not-approved-entry.js' : entry;
process.env.ZOE_LOCAL_RPC_TIMING_ENTRY = entry;
process.env.ZOE_LOCAL_RPC_TIMING_OUT = output;
if (fault === 'guard-io' || fault === 'exit-io') fs.writeFileSync = (name, ...args) => { if (name === output) throw Object.assign(new Error('synthetic observer permission denied'), {code:'EACCES'}); return write(name, ...args); };
if (fault === 'guard-race') fs.writeFileSync = (name, ...args) => { if (name === output) throw Object.assign(new Error('synthetic output race'), {code:'EEXIST'}); return write(name, ...args); };
if (fault === 'guard-race') process.argv[1] = '/tmp/not-approved-entry.js';
if (fault === 'startup-memory') process.memoryUsage = () => { throw new Error('synthetic startup memory failure'); };
const P = require(preload);
if (fault === 'exit-hash') fs.readFileSync = (name, ...args) => { if (name === preload) throw new Error('synthetic missing preload at exit'); return read(name, ...args); };
if (fault === 'exit-summary') Object.entries = () => { throw new Error('synthetic malformed summary'); };
if (fault === 'exit-resource') process.resourceUsage = () => { throw new Error('synthetic resource failure'); };
if (fault === 'timer-memory') process.memoryUsage = () => { throw new Error('synthetic timer memory failure'); };
if (fault === 'attach') {
    let called = false;
    const server = P.scopedHttp({attach(){throw new Error('synthetic malformed observer')}}).createServer(() => { called = true; });
    server.emit('request', {}, {}); assert.equal(called, true);
}
assert.equal(2 + 2, 4); assert.equal(typeof P.entryAllowed, 'function');
process.stdout.write('UNDERLYING_ASSERTIONS_PASS\n');
process.exitCode = Number(desired);
process.once('exit', () => process.stdout.write('UNDERLYING_EXIT_LISTENER_RAN\n'));
if (fault === 'timer-memory') setTimeout(() => process.stdout.write('UNDERLYING_TIMER_RAN\n'), 300);
`;
const rows = [];
for (const [fault, expected] of [['guard-io', 0], ['guard-race', 7], ['startup-memory', 0], ['exit-io', 7], ['exit-hash', 7], ['exit-summary', 7], ['exit-resource', 7], ['timer-memory', 7], ['attach', 7]]) {
    const r = spawnSync(process.execPath, ['-e', child, preload, fault, String(expected)], { encoding: 'utf8', timeout: 3000 });
    const ok = r.status === expected && r.stdout.includes('UNDERLYING_ASSERTIONS_PASS') && r.stdout.includes('UNDERLYING_EXIT_LISTENER_RAN') && (fault !== 'timer-memory' || r.stdout.includes('UNDERLYING_TIMER_RAN'));
    rows.push({ fault, expectedExit: expected, actualExit: r.status, pass: ok, stdout: r.stdout, stderr: r.stderr });
    console.log((ok ? 'PASS ' : 'FAIL ') + fault + ' exit=' + r.status + ' expected=' + expected);
}
const result = { revision, pass: rows.filter(r => r.pass).length, fail: rows.filter(r => !r.pass).length, cases: rows };
fs.writeFileSync(path.join(root, 'local-rpc-timing-failure-' + revision + '.json'), JSON.stringify(result, null, 2) + '\n');
process.exitCode = result.fail ? 1 : 0;
