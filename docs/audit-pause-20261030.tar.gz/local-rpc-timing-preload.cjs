'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const Module = require('node:module');
const http = require('node:http');

const EVIDENCE = '/workspace/zoe-audit-target-20261029';
const ENTRY = '/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root/audit-tools/supabase-money-multishop-test.js';
const FAKE = path.join(path.dirname(ENTRY), 'supabase-fake-server.js');
const ENTRY_SHA = '22888c50d588f1391596adfdc912bfd524687c1387cf72226eb3abcd6c91a253';
const FAKE_SHA = 'e7f01c48bca9474cc7e075b1756641ae09b7ff1f03394d1f7bea496c40b3faf6';
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const loopback = address => address === '127.0.0.1' || address === '::ffff:127.0.0.1';
let diagnosticFailures = 0;
const diagnosed = new Set();
function diagnostic(reason) {
    diagnosticFailures++;
    try {
        if (diagnosed.has(reason)) return;
        diagnosed.add(reason);
        process.stderr.write('RPC timing NOT AVAILABLE/PARTIAL: ' + reason + '. Underlying checker continues unchanged.\n');
    } catch (_) {}
}
function writeReport(output, report) {
    try { fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' }); }
    catch (_) { diagnostic('report output unavailable'); }
}

function endpointOf(req) {
    if (req.method !== 'POST' || typeof req.url !== 'string') return null;
    const endpoint = req.url.split('?', 1)[0];
    return /^\/rest\/v1\/rpc\/zoe_[a-z0-9_]{1,64}$/.test(endpoint) ? endpoint : null;
}

function eligible(server, req) {
    const address = server.address();
    return !!address && typeof address === 'object' && address.address === '127.0.0.1'
        && loopback(req.socket.localAddress) && loopback(req.socket.remoteAddress);
}

function distribution(values) {
    if (!values.length) return { count: 0, p50Ms: null, p95Ms: null, p99Ms: null, maxMs: null };
    const sorted = values.slice().sort((a, b) => a - b);
    const rank = p => sorted[Math.max(0, Math.ceil(sorted.length * p) - 1)];
    return { count: sorted.length, p50Ms: rank(0.50), p95Ms: rank(0.95), p99Ms: rank(0.99), maxMs: sorted.at(-1) };
}

function createObserver(limit = 100000) {
    const samples = [];
    const counts = Object.create(null);
    let inFlight = 0, started = 0, droppedSamples = 0, observerErrors = 0, attachedServers = 0;
    function attach(server) {
        attachedServers++;
        server.prependListener('request', (req, res) => {
            try {
                const endpoint = endpointOf(req);
                if (!endpoint || !eligible(server, req)) return;
                const start = process.hrtime.bigint();
                started++; inFlight++;
                let done = false;
                const record = status => {
                    if (done) return;
                    done = true; inFlight--;
                    try {
                        const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
                        const key = endpoint + ' ' + status;
                        counts[key] = (counts[key] || 0) + 1;
                        if (samples.length < limit) samples.push({ endpoint, status, durationMs });
                        else droppedSamples++;
                    } catch (_) { observerErrors++; }
                };
                res.once('finish', () => { try { record(res.statusCode); } catch (_) { observerErrors++; } });
                res.once('close', () => { try { record(0); } catch (_) { observerErrors++; } });
            } catch (_) { observerErrors++; }
        });
        return server;
    }
    function summary() {
        const completed = samples.filter(s => s.status > 0);
        const group = predicate => distribution(samples.filter(predicate).map(s => s.durationMs));
        const total = predicate => Object.entries(counts).reduce((n, [k, v]) => n + (predicate(Number(k.slice(k.lastIndexOf(' ') + 1))) ? v : 0), 0);
        const httpCompleted = total(s => s > 0), httpErrors = total(s => s >= 400);
        const byEndpointStatus = Object.entries(counts).map(([key, count]) => {
            const split = key.lastIndexOf(' '), endpoint = key.slice(0, split), status = Number(key.slice(split + 1));
            return { endpoint, status, totalCount: count, ...distribution(samples.filter(s => s.endpoint === endpoint && s.status === status).map(s => s.durationMs)) };
        });
        return {
            started, inFlightAtSnapshot: inFlight, attachedServers, observerErrors, sampleLimit: limit, droppedSamples,
            httpCompleted, httpErrors, httpErrorRate: httpCompleted ? httpErrors / httpCompleted : null,
            authorizationDenialStatuses401or403: total(s => s === 401 || s === 403),
            other4xx: total(s => s >= 400 && s < 500 && s !== 401 && s !== 403), server5xx: total(s => s >= 500),
            closedBeforeFinish: total(s => s === 0), expectedDenialsConfirmed: null,
            expectedDenialClassification: 'NOT INFERRED: HTTP status alone does not identify expected test denials; correlate with independent checker scenario evidence.',
            completedLatency: distribution(completed.map(s => s.durationMs)), successful2xxLatency: group(s => s.status >= 200 && s.status < 300),
            byEndpointStatus, samples
        };
    }
    return { attach, summary };
}

function scopedHttp(observer) {
    return new Proxy(http, {
        get(target, key, receiver) {
            if (key === 'createServer') return (...args) => {
                const server = Reflect.apply(http.createServer, http, args);
                try { observer.attach(server); } catch (_) { diagnostic('server observer attachment failed'); }
                return server;
            };
            return Reflect.get(target, key, receiver);
        }
    });
}

function installForFake(fakeFile, observer) {
    const original = Module._load;
    const wrapped = scopedHttp(observer);
    let intercepted = false;
    function loader(request, parent, isMain) {
        try {
            if ((request === 'http' || request === 'node:http') && parent && parent.filename === fakeFile) {
                intercepted = true;
                if (Module._load === loader) Module._load = original;
                return wrapped;
            }
        } catch (_) { diagnostic('module observation failed'); }
        return Reflect.apply(original, this, [request, parent, isMain]);
    }
    Module._load = loader;
    return { intercepted: () => intercepted, restore() { if (Module._load === loader) Module._load = original; } };
}

function entryAllowed(actualEntry, configuredEntry, entryHash, fakeHash) {
    return actualEntry === ENTRY && configuredEntry === ENTRY && entryHash === ENTRY_SHA && fakeHash === FAKE_SHA;
}

function activate() {
    let output, hook, timer;
    try {
        if (!process.env.ZOE_LOCAL_RPC_TIMING_OUT) return;
        output = path.resolve(process.env.ZOE_LOCAL_RPC_TIMING_OUT);
        if (path.dirname(output) !== EVIDENCE || !/^[a-z0-9_-]+\.json$/.test(path.basename(output)) || fs.existsSync(output)) {
            diagnostic('output must be a new JSON file in the evidence directory');
            return;
        }
        let guard = false;
        try { guard = entryAllowed(path.resolve(process.argv[1] || ''), process.env.ZOE_LOCAL_RPC_TIMING_ENTRY, sha(ENTRY), sha(FAKE)); } catch (_) {}
        if (!guard) {
            writeReport(output, { status: 'NOT MEASURED', reason: 'Exact entry/hash allowlist did not match; no hook installed.' });
            return;
        }
        const observer = createObserver();
        hook = installForFake(FAKE, observer);
        const startedAt = process.hrtime.bigint(), cpuStart = process.cpuUsage(), memStart = process.memoryUsage();
        let rssPeak = memStart.rss, heapUsedPeak = memStart.heapUsed, resourceMeasurementErrors = 0;
        const sampleMemory = () => {
            try { const m = process.memoryUsage(); rssPeak = Math.max(rssPeak, m.rss); heapUsedPeak = Math.max(heapUsedPeak, m.heapUsed); }
            catch (_) { resourceMeasurementErrors++; diagnostic('memory sampling unavailable'); }
        };
        timer = setInterval(sampleMemory, 250); timer.unref();
        process.once('exit', code => {
            try {
                clearInterval(timer); sampleMemory(); hook.restore();
                const metrics = observer.summary(), cpu = process.cpuUsage(cpuStart), resources = process.resourceUsage();
                const status = diagnosticFailures || resourceMeasurementErrors || metrics.observerErrors ? 'PARTIAL' : hook.intercepted() && metrics.started > 0 ? 'MEASURED' : 'NOT MEASURED';
                const result = {
                    status, checkerExitCode: code, diagnosticFailures, resourceMeasurementErrors,
                    scope: { entry: ENTRY, fakeServer: FAKE, entrySha256: ENTRY_SHA, fakeSha256: FAKE_SHA, preloadSha256: sha(__filename) },
                    timingDefinition: 'Server request-event to response finish; status 0 means close before finish. Includes upload, auth, pool wait, SQL and serialization. Excludes connection setup, browser round-trip, UI convergence and completion after server finish.',
                    resources: { durationMs: Number(process.hrtime.bigint() - startedAt) / 1e6, parentUserCpuMs: cpu.user / 1000, parentSystemCpuMs: cpu.system / 1000, parentRssAtStartBytes: memStart.rss, parentSampledPeakRssBytes: rssPeak, parentSampledPeakHeapUsedBytes: heapUsedPeak, parentLifetimeMaxRssKiB: resources.maxRSS, memorySampleIntervalMs: 250 },
                    limits: ['Parent Node process resources only; excludes PostgreSQL and Chromium child resources.', 'Exact nearest-rank quantiles; p99 with fewer than100 samples has little tail resolution.', 'No body inspection: HTTP200 application-level CAS conflicts/errors are not classified.', 'Artificial fault pauses and aborts are reported; this is not healthy-production latency or capacity.', 'If samples are truncated, quantiles describe retained first samples only; total status counts remain complete.', 'Instrumentation overhead is not subtracted; exit report is unavailable on SIGKILL.'],
                    ...metrics
                };
                writeReport(output, result);
            } catch (_) {
                diagnostic('exit report construction unavailable');
                writeReport(output, { status: 'NOT AVAILABLE', reason: 'Observer exit report construction failed.', checkerExitCode: code });
            }
        });
    } catch (_) {
        try { if (timer) clearInterval(timer); } catch (_) {}
        try { if (hook) hook.restore(); } catch (_) {}
        diagnostic('observer activation unavailable');
        if (output) writeReport(output, { status: 'NOT AVAILABLE', reason: 'Observer activation failed; no measurement claimed.' });
    }
}

module.exports = { createObserver, scopedHttp, installForFake, endpointOf, eligible, distribution, entryAllowed, ENTRY, FAKE, ENTRY_SHA, FAKE_SHA };
activate();
