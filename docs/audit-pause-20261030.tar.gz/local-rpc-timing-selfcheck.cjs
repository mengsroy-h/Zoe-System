'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const http = require('node:http');
const { EventEmitter } = require('node:events');
const P = require('./local-rpc-timing-preload.cjs');
const out = '/workspace/zoe-audit-target-20261029/local-rpc-timing-selfcheck.json';
let pass = 0;
function check(name, body) { body(); pass++; console.log('PASS ' + name); }
function request(url, options = {}) {
    return new Promise(resolve => {
        const req = http.request(url, { method: options.method || 'POST', headers: { authorization: 'Bearer DO_NOT_LOG_AUTH', 'content-type': 'application/json' } }, res => {
            res.resume(); res.once('end', () => resolve({ status: res.statusCode }));
        });
        req.once('error', () => resolve({ status: 0 }));
        req.end(JSON.stringify({ p_payload: 'DO_NOT_LOG_BODY' }));
    });
}
(async () => {
    const started = process.hrtime.bigint();
    check('exact main entry and source hashes required', () => {
        assert(P.entryAllowed(P.ENTRY, P.ENTRY, P.ENTRY_SHA, P.FAKE_SHA));
        assert(!P.entryAllowed('/tmp/not-approved.js', P.ENTRY, P.ENTRY_SHA, P.FAKE_SHA));
        assert(!P.entryAllowed(P.ENTRY, '/tmp/not-approved.js', P.ENTRY_SHA, P.FAKE_SHA));
        assert(!P.entryAllowed(P.ENTRY, P.ENTRY, 'changed', P.FAKE_SHA));
        assert(!P.entryAllowed(P.ENTRY, P.ENTRY, P.ENTRY_SHA, 'changed'));
    });
    check('endpoint selection excludes query, auth, OPTIONS, other methods and absolute URLs', () => {
        assert.equal(P.endpointOf({ method: 'POST', url: '/rest/v1/rpc/zoe_read?secret=DO_NOT_LOG_QUERY' }), '/rest/v1/rpc/zoe_read');
        for (const [method, url] of [['POST', '/auth/v1/token'], ['OPTIONS', '/rest/v1/rpc/zoe_write'], ['GET', '/rest/v1/rpc/zoe_read'], ['POST', 'http://external.invalid/rest/v1/rpc/zoe_read'], ['POST', '/rest/v1/rpc/not_zoe']]) assert.equal(P.endpointOf({ method, url }), null);
    });
    check('only loopback-bound servers and loopback peers admitted', () => {
        const req = { socket: { localAddress: '127.0.0.1', remoteAddress: '127.0.0.1' } };
        assert(P.eligible({ address: () => ({ address: '127.0.0.1', port: 49321 }) }, req));
        for (const address of ['0.0.0.0', '::', '192.0.2.10']) assert(!P.eligible({ address: () => ({ address }) }, req));
        assert(!P.eligible({ address: () => ({ address: '127.0.0.1' }) }, { socket: { localAddress: '127.0.0.1', remoteAddress: '192.0.2.11' } }));
    });
    check('nearest-rank quantile calculation independently known values', () => {
        assert.deepEqual(P.distribution(Array.from({ length: 100 }, (_, i) => i + 1)), { count: 100, p50Ms: 50, p95Ms: 95, p99Ms: 99, maxMs: 100 });
        assert.equal(P.distribution([]).p99Ms, null);
    });
    const observer = P.createObserver();
    const hook = P.installForFake(P.FAKE, observer);
    check('unrelated http import remains original', () => assert.equal(require('http'), http));
    const { startFakeSupabase } = require(P.FAKE);
    check('only actual fake module http import intercepted', () => assert(hook.intercepted()));
    const pool = { async connect() { return { release() {}, async query(sql) {
        if (String(sql).includes('from pg_proc')) return { rows: [{ names: ['p_payload'], types: ['jsonb'], setof: false, ret: 'jsonb', rettype: 'b' }] };
        return { rows: [{ r: { ok: true } }] };
    } }; } };
    let fake;
    try {
        fake = await startFakeSupabase({ pool });
        let reached, release;
        const entered = new Promise(r => { reached = r; }), gate = new Promise(r => { release = r; });
        fake.setRpcHook(async ({ phase }) => { if (phase === 'before') { reached(); await gate; } });
        const pending = request(fake.url + '/rest/v1/rpc/zoe_read?secret=DO_NOT_LOG_QUERY');
        await entered;
        check('actual handler async barrier is in flight before response finish', () => {
            const m = observer.summary(); assert.equal(m.started, 1); assert.equal(m.httpCompleted, 0); assert.equal(m.inFlightAtSnapshot, 1);
        });
        release(); assert.equal((await pending).status, 200);
        fake.setRpcHook(() => ({ status: 403, body: { message: 'DO_NOT_LOG_RESPONSE' } }));
        assert.equal((await request(fake.url + '/rest/v1/rpc/zoe_write')).status, 403);
        fake.setRpcHook(() => ({ status: 500, body: { message: 'DO_NOT_LOG_RESPONSE' } }));
        assert.equal((await request(fake.url + '/rest/v1/rpc/zoe_pull')).status, 500);
        fake.setRpcHook(() => 'drop');
        assert.equal((await request(fake.url + '/rest/v1/rpc/zoe_now')).status, 0);
        await request(fake.url + '/auth/v1/health', { method: 'GET' });
        await request(fake.url + '/rest/v1/rpc/zoe_read', { method: 'OPTIONS' });
        await new Promise(r => setImmediate(r));
        const metrics = observer.summary();
        check('actual fake server finish and premature-close counts are exact', () => {
            assert.equal(metrics.started, 4); assert.equal(metrics.httpCompleted, 3); assert.equal(metrics.closedBeforeFinish, 1); assert.equal(metrics.inFlightAtSnapshot, 0); assert.equal(metrics.observerErrors, 0);
        });
        check('all HTTP errors separated from unclassified 401/403 and 5xx', () => {
            assert.equal(metrics.httpErrors, 2); assert.equal(metrics.httpErrorRate, 2 / 3); assert.equal(metrics.authorizationDenialStatuses401or403, 1); assert.equal(metrics.server5xx, 1); assert.equal(metrics.expectedDenialsConfirmed, null);
        });
        check('only endpoint/status/duration in samples; no credential/query/payload leaked', () => {
            for (const s of metrics.samples) { assert.deepEqual(Object.keys(s).sort(), ['durationMs', 'endpoint', 'status']); assert(s.durationMs >= 0); }
            assert(!JSON.stringify(metrics).includes('DO_NOT_LOG'));
        });
        const unrelated = http.createServer((req, res) => res.end('ok'));
        await new Promise(r => unrelated.listen(0, '127.0.0.1', r));
        await request('http://127.0.0.1:' + unrelated.address().port + '/rest/v1/rpc/zoe_read');
        await new Promise(r => unrelated.close(r));
        check('other real loopback HTTP server is not observed', () => assert.equal(observer.summary().started, 4));
        check('bounded samples disclose truncation and finish/close is counted once', () => {
            const small = P.createObserver(1), server = new EventEmitter(); server.address = () => ({ address: '127.0.0.1' }); small.attach(server);
            for (let i = 0; i < 2; i++) { const res = new EventEmitter(); res.statusCode = 200; server.emit('request', { method: 'POST', url: '/rest/v1/rpc/zoe_read', socket: { localAddress: '127.0.0.1', remoteAddress: '127.0.0.1' } }, res); res.emit('finish'); res.emit('close'); }
            const m = small.summary(); assert.equal(m.httpCompleted, 2); assert.equal(m.samples.length, 1); assert.equal(m.droppedSamples, 1); assert.equal(m.closedBeforeFinish, 0);
        });
        fs.writeFileSync(out, JSON.stringify({ pass, fail: 0, durationMs: Number(process.hrtime.bigint() - started) / 1e6, actualFakeModule: P.FAKE, database: 'stubbed only for observer selfcheck; not database performance evidence', metrics }, null, 2) + '\n');
    } finally { if (fake) await fake.close(); hook.restore(); }
})().catch(e => { console.error(e.stack); process.exitCode = 1; });
