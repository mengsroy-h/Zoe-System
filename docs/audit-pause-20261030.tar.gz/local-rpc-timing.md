# Local Supabase RPC timing observer — prepared, scale results not yet measured

Frozen source: `27f00719aa59645b1b74d083d3ac7da0019113f5`; measure root `/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root`. No tracked file changed, no build or load test run, and the already-running aggregate was not instrumented. Source/tool fingerprints are in `local-rpc-timing-inputs.json`.

## Scope and measured interval

Reviewed actual `audit-tools/supabase-fake-server.js`: line240 creates the HTTP request listener, body collection precedes the RPC dispatch, `rpc()` checks authentication and obtains a database pool connection, executes the real SQL transaction, and `send()` writes status and ends the response. It binds only `127.0.0.1` at line305. The parent multishop checker starts this server and routes actual browser adapter RPCs through it.

The external preload admits exactly the final `supabase-money-multishop-test.js` absolute main entry and its recorded SHA256, plus the exact sibling fake-server SHA256. A temporary `Module._load` wrapper gives only that fake module a proxied `http.createServer`, then restores the loader. The original server callback and arguments are unchanged. The proxy adds passive request/response listeners; other static or unrelated servers retain the original HTTP module. Both bound address and local/remote socket addresses must be loopback. No external endpoint is contacted by the observer.

For POST `/rest/v1/rpc/zoe_*`, elapsed time starts at the server `request` event and ends at response `finish`. A premature `close` is recorded separately with status0. This includes upload, authorization, signature lookup, pool queueing, SQL and serialization. It excludes TCP connection setup, browser round-trip/UI work and sync convergence, and does not establish that the client received the response. The observer never reads headers or bodies; raw records contain only `endpoint`, `status`, `durationMs`, with the query stripped before admission.

Summaries contain exact nearest-rank p50/p95/p99/max by endpoint/status, all completed requests, and successful2xx requests. All HTTP errors are counted; 401/403 candidates are separate from other4xx and5xx. **Expected denials are not inferred from status**: `expectedDenialsConfirmed` stays null until independent checker scenario evidence supports classification. HTTP200 CAS conflicts or application errors cannot be detected without body inspection, which this observer deliberately avoids. Artificial faults are not a healthy-service performance baseline.

Parent Node CPU user/system time, elapsed lifetime and sampled RSS/heap peaks (250ms interval) are reported. They exclude PostgreSQL/Chromium child resources; parent lifetime maxRSS is labelled separately. Instrumentation overhead is included, not subtracted. Samples are bounded at100000; truncation is explicit and aggregate status totals remain complete. A truncated distribution represents only retained samples. A p99 with fewer than100 samples has poor tail resolution. SIGKILL prevents the exit report; a missing report must be treated as NOT MEASURED.

## Observer selfcheck

`local-rpc-timing-selfcheck-final.json`: **12 PASS / 0 FAIL**, approximately40ms, bounded by timeout12s. It loads the actual allowlisted fake server with a tiny stub pool solely to validate instrumentation; it does not claim database performance. Controls verify exact main/hash gating, loopback/endpoint restriction, unrelated HTTP-module/server isolation, async request barrier before response finish, exact finished/aborted counts, error separation, no secret/query/body strings in output, independent known quantiles and bounded sample disclosure. No load or production network was used. Raw logs: `logs/local-rpc-timing-selfcheck.log` (initial) and `logs/local-rpc-timing-selfcheck-final.log` (revised observer).

```sh
node --check /workspace/zoe-audit-target-20261029/local-rpc-timing-preload.cjs
timeout 12 node /workspace/zoe-audit-target-20261029/local-rpc-timing-selfcheck.cjs
```

## Later isolated scale runs (parent-controlled)

These are proposed exact commands, **not executed during preparation**. Run sequentially after the aggregate releases resources. Keep the original checker exit status and assertions. Use direct `node --require`; do not put the preload in global `NODE_OPTIONS`. Output files must not already exist: the observer refuses to overwrite evidence. The allowlist fails closed if entry/server source hashes change.

```sh
cd /workspace/Zoe-System-target/ZoeW/dist-audit/measure-root
SBMONEY_APP_DIR=/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root \
ZOE_REPO_ROOT=/workspace/Zoe-System-target \
SUPABASE_DEPS_DIR=/workspace/Zoe-System-target/supabase/node_modules \
SBMONEY_CHROME=/usr/bin/chromium SBMONEY_STRICT=1 SBMONEY_SHOPS=4 SBMONEY_DEVICES=3 SBMONEY_OPS=6 \
ZOE_LOCAL_RPC_TIMING_ENTRY=/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root/audit-tools/supabase-money-multishop-test.js \
ZOE_LOCAL_RPC_TIMING_OUT=/workspace/zoe-audit-target-20261029/scale4-rpc-timing.json \
node --require /workspace/zoe-audit-target-20261029/local-rpc-timing-preload.cjs audit-tools/supabase-money-multishop-test.js \
> /workspace/zoe-audit-target-20261029/logs/scale4-rpc-timing-checker.log 2>&1

SBMONEY_APP_DIR=/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root \
ZOE_REPO_ROOT=/workspace/Zoe-System-target \
SUPABASE_DEPS_DIR=/workspace/Zoe-System-target/supabase/node_modules \
SBMONEY_CHROME=/usr/bin/chromium SBMONEY_STRICT=1 SBMONEY_SHOPS=8 SBMONEY_DEVICES=3 SBMONEY_OPS=6 \
ZOE_LOCAL_RPC_TIMING_ENTRY=/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root/audit-tools/supabase-money-multishop-test.js \
ZOE_LOCAL_RPC_TIMING_OUT=/workspace/zoe-audit-target-20261029/scale8-rpc-timing.json \
node --require /workspace/zoe-audit-target-20261029/local-rpc-timing-preload.cjs audit-tools/supabase-money-multishop-test.js \
> /workspace/zoe-audit-target-20261029/logs/scale8-rpc-timing-checker.log 2>&1
```

The checker itself reports actual operations/devices and coverage. Pair its exit code/assertion report with the timing file; a measured HTTP distribution is not evidence of correctness, completed convergence or production capacity. Inspect `status`, `checkerExitCode`, `inFlightAtSnapshot`, `observerErrors` and `droppedSamples` before interpreting quantiles.

## Failure isolation correction and review

Independent review found observer-only failures could escape the original preload: a denied/racing NOT MEASURED output write could stop startup, and exit-report construction could interrupt later exit listeners. The v1 observer is preserved in `local-rpc-timing-preload-v1.cjs`, with its original manifest `local-rpc-timing-inputs-v1.json`.

The revised observer catches activation, output, timer sampling, exit construction and attachment failures. It emits fixed redacted diagnostics and, when writable, NOT AVAILABLE/PARTIAL status; it does not change the checker exit code or install uncaught-exception handlers. Original product HTTP/require errors retain their original behavior. Ordinary observer failure cannot turn a failing checker green; unavailable metrics are not performance evidence.

`local-rpc-timing-failure-selfcheck.cjs` runs nine tiny isolated Node sentinel processes (no app/PG load), with permission-denied writes, output creation race, startup/timer memory exceptions, exit hash/summary/resource/write exceptions, and a malformed observer attachment. Baseline: **1 PASS / 8 FAIL**. Fixed: **9 PASS / 0 FAIL**; underlying assertions, the later exit listener and requested exit0/exit7 are preserved. JSON/logs are `local-rpc-timing-failure-baseline.json`, `local-rpc-timing-failure-fixed.json` and matching logs. The twelve behavior/privacy controls also pass on the revised code. Independent reviewer approved the corrected observer for later bounded measurement. The refreshed input manifest is authoritative for preload SHA256; no product source changed.
