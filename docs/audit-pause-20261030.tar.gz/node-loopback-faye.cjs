'use strict';
const faye = require('/workspace/Zoe-System-target/ZoeW/node_modules/faye-websocket');
const Original = faye.Client;
function optionsFor(url, options) {
    let target;
    try { target = new URL(url); } catch (_) { return options; }
    if (target.protocol !== 'ws:' || target.hostname !== '127.0.0.1') return options;
    if (!options || !Object.prototype.hasOwnProperty.call(options, 'proxy')) return options;
    const local = { ...options };
    delete local.proxy;
    return local;
}
function LoopbackClient(url, protocols, options) {
    return new Original(url, protocols, optionsFor(url, options));
}
Object.setPrototypeOf(LoopbackClient, Original);
LoopbackClient.prototype = Original.prototype;
faye.Client = LoopbackClient;
module.exports = { optionsFor };
