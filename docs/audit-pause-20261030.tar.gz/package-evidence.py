#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,tarfile,time
ROOT=pathlib.Path('/workspace/zoe-audit-target-20261029')
EXT={'.md','.json','.tsv','.txt','.log','.patch','.py','.cjs','.js','.sh','.bundle'}
parser=argparse.ArgumentParser();parser.add_argument('--write',action='store_true');parser.add_argument('--label',default='audit-evidence');a=parser.parse_args()
if not a.label.replace('-','').isalnum():raise SystemExit('invalid label')
output=ROOT/(a.label+'.tar.gz');manifest=ROOT/(a.label+'-manifest.json')
if a.write and (output.exists() or manifest.exists()):raise SystemExit('refuse overwrite')
def allowed(p):
 rel=p.relative_to(ROOT)
 if p.is_symlink() or not p.is_file():return False
 if any(x.startswith('.') or x in {'node_modules','cache','caches'} for x in rel.parts):return False
 if p in {output,manifest} or p.suffix not in EXT:return False
 if len(rel.parts)==1:return True
 first=rel.parts[0]
 return first in {'logs','raw-final','raw-verification','numeric-verification','numeric-verification-scale4','numeric-verification-scale8','proposed'} and not any('isolated' in x or 'node_modules' in x or x.endswith('-tree') for x in rel.parts)
files=[]
for p in ROOT.iterdir():
 if allowed(p):files.append(p)
for directory in ['logs','raw-final','raw-verification','numeric-verification','numeric-verification-scale4','numeric-verification-scale8','proposed']:
 d=ROOT/directory
 if d.is_dir():
  for p in d.rglob('*'):
   if allowed(p):files.append(p)
files=sorted(set(files));rows=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
result={'created':time.time(),'files':rows,'file_count':len(rows),'bytes':sum(x['bytes'] for x in rows),'exclusions':'No environment/credentials files, dependency/cache trees, full isolated checkouts or symlinks. Original source is recoverable from non-force Git checkpoints and bundle. Secret survey must be reviewed before --write.'}
if a.write:
 manifest.write_text(json.dumps(result,indent=2)+'\n')
 with tarfile.open(output,'x:gz',compresslevel=6) as archive:
  for p in files:archive.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
  archive.add(manifest,arcname=manifest.name,recursive=False)
 print(json.dumps({'archive':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'files':len(files),'bytes':output.stat().st_size}))
else:print(json.dumps({'planned_files':len(files),'planned_bytes':result['bytes'],'write':False}))
