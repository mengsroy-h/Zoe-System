# Proposed authoritative numeric witness

Ready for a parent-controlled post-fix final aggregate run. Independent read-only review found no blocking defect. No heavy matrix was run during preparation. No tracked file changed.

`MONEYMD_DEBUG=1` / `SBMONEY_DEBUG=1` are insufficient: they print package totals and phone-reference sums only during seeded fuzz, do not print customer cardinality or all deterministic checkpoints, and may dump entire rows on failures. This observer instead collects sanitized numeric fields at existing authoritative reads.

Set these variables in the final aggregate process environment, preserving the existing `NODE_OPTIONS` value:

```sh
export ZOE_NUMERIC_ROOT=/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root
export ZOE_NUMERIC_OUTPUT_DIR=/workspace/zoe-audit-target-20261029/numeric-final
export NODE_OPTIONS="${NODE_OPTIONS:+$NODE_OPTIONS }--require=/workspace/zoe-audit-target-20261029/proposed/numeric-witness/preload.cjs"
```

Then use the parent's final-run orchestration normally. **Do not rerun the old `run-final.py` blindly**, because it writes existing final log/report paths; the parent owns preservation and scheduling. The existing environment setup still adds its Playwright preload. No numeric observer is installed unless `process.argv[1]` is exactly the selected measure-root's Firebase or Supabase matrix entry. Other checkers, helper-only imports, guardian mutants and mutated shadow directories stay untouched. Exact source module allowlist: the two matrix runners plus their shared `money-cookie-blob.js`.

Each selected process writes a new `firebase-PID.jsonl` or `supabase-PID.jsonl` and a corresponding manifest. The manifest hashes original and instrumented module bytes, observer/preload bytes, shared oracle and app bundle. Stripping observer-tagged lines must reproduce the original source byte-for-byte; compilation is checked before running an instrumented module. Assertions and existing control flow are preserved. No extra network/DB reads, waits, callbacks into App code or mutations are added.

Observer calls consume deep-cloned existing snapshots and synchronously emit numeric actual daily/monthly revenue, bounded ledger operation witnesses, keyed deduction entries, history/trash/barcode counts, pickup package/customer counts, hashed owner references, and target barcode status. Consecutive records include previous state and delta. Tokens and owner identities are stable fingerprints; cookies, credentials and raw phone numbers never enter output. Synthetic branch tags such as `s0` are retained.

Financial expected values at deterministic checkpoints are passed from the existing scripted expectation model (`createRevenueExpectation`). Additional barcode/pickup/customer expected values are independently calculated by the external observer, without importing App mutation helpers. This is independent from the functions under test, not a claim that all concurrent business interleavings have a separate sequential model.

The observer catches its own calculation/output errors and records witness failure separately. It never catches checker assertions or changes checker exit status. A missing/failed observer must be reported as incomplete evidence, even if the checker passes. Errors before output creation print `NUMERIC_WITNESS_SETUP_FAILED`; errors writing final metadata print `NUMERIC_WITNESS_MANIFEST_FAILED`.

After completed processes:

```sh
python3 /workspace/zoe-audit-target-20261029/proposed/numeric-witness/analyze.py /workspace/zoe-audit-target-20261029/numeric-final
```

The analyzer emits `numeric-summary.json` and `.md`. It requires a successful original checker exit, complete module coverage, no instrumentation errors, row-count agreement, and matching converged comparisons. Prepared restore snapshots are explicitly intermediate and can legitimately contain duplicate physical copies while finalization is pending. They remain visible without being mislabeled final invariant failures.

The same observer supports `SBMONEY_SHOPS=8`, `SBMONEY_DEVICES=3` in a later dedicated scale run (24 Chromium contexts). Original matrix scope stays unchanged: deterministic mode/action/fault matrix in shop0, neighbor isolation snapshots from all other shops, seeded concurrent rounds in every shop. Increasing shops does not imply a full deterministic matrix in each shop. Start a separate output directory and run after the aggregate gate; no heavy execution is authorized by this preparation note alone beyond the parent's existing scope.

For Firebase seeded fuzz, the first checkpoint of a run may have no earlier authoritative snapshot available; the deterministic daily-flow matrix has explicit before-action observations. Numeric fields are revenue aggregates and persisted operation metadata; no nonexistent bank balance or append-only accounting ledger is invented. Instrumentation adds serialization/I/O overhead, so instrumented elapsed times should not replace performance baseline measurements.

Local preparation validation:

```sh
node /workspace/zoe-audit-target-20261029/proposed/numeric-witness/self-check.cjs
```

`self-check.log`: 13 PASS, 0 FAIL; no backend execution. Controls cover byte-identical original code after removing observer lines, strict entry allowlist, known package3/customer2 fixture, six independently broken invariants still failing, jointly wrong barcode/ledger caught by scripted expectations, output failure isolation, cloned inputs, and exact sequential deltas. These controls validate instrumentation, not the requested backend numeric witness itself. That gap remains pending until the actual instrumented run completes.

Independent reviewer limits: serialization/cloning/hashing/file output add CPU/I/O and can affect timing; the observer comparisons are not a replacement for original duplicate/lost/orphan/known-code assertions; numeric coercion to finite numbers does not independently validate malformed database schemas. Original checker verdicts remain authoritative.
