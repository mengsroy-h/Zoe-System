from pathlib import Path
import argparse,json,collections
p=argparse.ArgumentParser();p.add_argument('directory');args=p.parse_args();root=Path(args.directory)
runs=[];allrows=[]
for manifest in sorted(root.glob('*.jsonl.manifest.json')):
 m=json.loads(manifest.read_text());rows=[json.loads(l) for l in Path(m['output']).read_text().splitlines() if l.strip()]
 bad=[{'sequence':r['sequence'],'label':r['label'],'comparisons':[k for k,v in r['comparisons'].items() if v is False]} for r in rows if r['convergedCheckpoint'] and any(v is False for v in r['comparisons'].values())]
 good=m['checkerExitCode']==0 and m['moduleCoverageComplete'] and not m['errors'] and len(rows)==m['observations'] and rows and not bad
 runs.append({'manifest':str(manifest),'backend':rows[0]['backend'] if rows else None,'status':'PASS' if good else 'PARTIAL_OR_FAILED','checker_exit':m['checkerExitCode'],'observations':len(rows),'converged_checkpoints':sum(r['convergedCheckpoint'] for r in rows),'scripted_financial_observations':sum(r['expected']['scriptedDaily'] is not None for r in rows),'tenants':sorted(set(r['tenant'] for r in rows)),'phase_counts':dict(collections.Counter(r['phase'] for r in rows)),'bad_converged':bad,'errors':m['errors']})
 allrows.extend(rows)
report={'status':'PASS' if runs and all(r['status']=='PASS' for r in runs) else 'PARTIAL_OR_FAILED','runs':runs,'observations':len(allrows),'note':'Observation counts are not additional tests. Intermediate prepared restore snapshots may intentionally contain pending duplicate barcode state; only converged checkpoints are compared as final invariants. Main checker exit is preserved independently.'}
(root/'numeric-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# Numeric authoritative witness','',f'Status: **{report["status"]}**. Observations: **{len(allrows)}**. These are persisted state witnesses, not additional tests.','', '| Backend | Status | Observations | Converged checkpoints | Tenant scopes |','|---|---|---:|---:|---|']
for r in runs:lines.append(f'| {r["backend"]} | {r["status"]} | {r["observations"]} | {r["converged_checkpoints"]} | {", ".join(r["tenants"])} |')
lines+=['','Selected daily-flow checkpoints; the JSONL retains every observed step including explicit before-action snapshots, offline state and restore preparation.','', '| Backend/mode/scenario | COD/DOD/revenue count | Picked-up packages/customers | History/trash barcode counts | Target |','|---|---|---|---|---|']
for row in allrows:
 if row['phase']!='checkpoint' or not any(row['label'].startswith(prefix) for prefix in ['remove/duplicate/','delete/duplicate/','pickup2h/duplicate/','abandon8d/duplicate/','remove-signed/duplicate/','sign-after-claim/','sign-after-prepared/']):continue
 a=row['actual'];d=a['daily'];pick=a['pickup'];b=a['barcodes'];t=a['target']
 lines.append(f'| {row["backend"]}/{row["mode"]}/{row["label"]} | {d["cod"]}/{d["dod"]}/{d["revenueCount"]} | {pick["packages"]}/{pick["customers"]} | {b["history"]}/{b["trash"]} | '+(', '.join(x['location']+('/deducted' if x['deducted'] else '/counted') for x in t) or 'none')+' |')
lines+=['','`actual.daily/monthly` preserve COD/DOD/count, bounded operation-ring fingerprints and keyed deduction-entry numeric fields. `previous` and `delta` provide consecutive actual before/after values for each tenant/day. `expected.scriptedDaily/Monthly` come from the existing independently accumulated scenario oracle; pickup/customer expectations are recomputed separately from parcel identity/state, never copied from pickup counters. Raw phone numbers, credentials and cookies are omitted.','', 'Limits: these fields are revenue aggregates and persisted operation witnesses, not an invented bank balance or append-only ledger. Intermediate prepared snapshots may differ from converged invariants. First seeded-fuzz checkpoint may lack a preceding authoritative snapshot; concurrent fuzz expected values are state-derived, not an independent serial business model. Instrumentation overhead excludes this run from latency benchmarking. No production/live ZTO validation.']
(root/'numeric-summary.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(report,ensure_ascii=False))
