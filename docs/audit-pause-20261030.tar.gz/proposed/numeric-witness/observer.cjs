'use strict';
// Observational only: consumes already-read synthetic snapshots; no DB/network/App calls.
const crypto = require('node:crypto');
const r2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const number = v => Number.isFinite(Number(v)) ? Number(v) : 0;
const hash = v => crypto.createHash('sha256').update(String(v)).digest('hex').slice(0, 16);
const clone = v => JSON.parse(JSON.stringify(v));
const values = v => v && typeof v === 'object' ? Object.values(v).filter(Boolean) : [];
const ownerKey = it => it.phone && it.phone !== 'គ្មានលេខ' ? String(it.phone).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0,64) : '__item_' + it.id;
const regKey = code => String(code || '').trim().toUpperCase().replace(/[%.#$\[\]\/\x00-\x1F\x7F]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase().padStart(2,'0'));
function ledger(row) {
  row ||= {};
  return { cod: r2(number(row.codDollar)), dod: r2(number(row.dodDollar)), revenueCount: number(row.totalCount),
    latestOperationFingerprint: row.op ? hash(row.op) : null,
    operationRing: Object.entries(row.ops || {}).map(([key,seq]) => ({operationFingerprint:hash(key), sequence:number(seq)})).sort((a,b)=>a.sequence-b.sequence),
    deductionEntries: Object.entries(row.ded || {}).map(([key,v]) => ({entityFingerprint:hash(key),at:number(v?.at),cod:number(v?.cod),dod:number(v?.dod),count:number(v?.count),back:v?.back===true,undo:v?.undo===true})).sort((a,b)=>a.entityFingerprint.localeCompare(b.entityFingerprint)) };
}
function snapshot(ctx, tree) {
  tree ||= {};
  const day=ctx.day, month=ctx.month || day.slice(0,7), target=ctx.targetCode;
  const all=[], phones={}, expectedPickupKeys=[], seen=new Map(), registry=tree.zoew_barcode_registry || {};
  let cod=0,dod=0,revenueCount=0,packages=0;
  for(const [location,bag] of [['history',tree.zoew_scan_history_cod_dod],['trash',tree.zoew_recently_deleted_cod_dod]]) {
    for(const it of values(bag)) {
      const bcs=it.barcodes ? values(it.barcodes) : it.barcode ? [{code:it.barcode,cod:it.cod,dod:it.dod,isClosed:it.isClosed,isDeducted:it.isDeducted}] : [];
      const reason=typeof it.trashReason==='string' ? it.trashReason : it.isFromDeletion ? 'kept' : 'remove';
      for(const b of bcs) {
        if(!b?.code)continue;
        const identity=String(b.code).trim().toUpperCase(), key=regKey(b.code);
        let pending=false;
        if(location==='history' && (it.restoreClaimId!==undefined || it.restoreClaimToken!==undefined)) {
          let added=null;
          try { if(typeof it.restoreClaimToken==='string' && typeof it.restoreAddedCodes==='string') added=JSON.parse(it.restoreAddedCodes); } catch {}
          pending=!Array.isArray(added) || added.includes(b.code);
        }
        const picked=b.isClosed===true && !(location==='trash' && ['remove','returned','misplaced','sent'].includes(reason)) && !pending;
        const row={entityFingerprint:hash(it.id),barcodeFingerprint:hash(identity),location,scanDay:it.scanDate,
          cod:number(b.cod),dod:number(b.dod),closed:b.isClosed===true,deducted:b.isDeducted===true,
          pickedCounted:picked,restorePending:pending,trashReason:location==='trash'?reason:null,
          restoreBlocked:it.restoreBlocked===true,signedAt:number(b.ztoSignedAt),returnedAt:number(b.ztoReturnedAt),
          claimFingerprint:typeof b.trashClaim==='string'?hash(b.trashClaim):null,
          restoreClaimFingerprint:it.restoreClaim?.token?hash(it.restoreClaim.token):null,
          registryPresent:registry[key]===true};
        all.push(row);seen.set(identity,(seen.get(identity)||0)+1);
        if(it.scanDate!==day)continue;
        if(b.isDeducted!==true){cod+=number(b.cod);dod+=number(b.dod);revenueCount++;}
        if(picked){packages++;const owner=hash(ownerKey(it));phones[owner]=(phones[owner]||0)+1;expectedPickupKeys.push({barcodeFingerprint:hash(key),ownerFingerprint:owner});}
      }
    }
  }
  const pickup=(tree.zoew_daily_pickup_cod_dod||{})[day]||{}, actualPhones=pickup.pickedUpPhones||{};
  expectedPickupKeys.sort((a,b)=>a.barcodeFingerprint.localeCompare(b.barcodeFingerprint));
  const actualPickupKeys=Object.entries(pickup.pickedUpBarcodes||{}).map(([key,owner])=>({barcodeFingerprint:hash(key),ownerFingerprint:hash(owner)})).sort((a,b)=>a.barcodeFingerprint.localeCompare(b.barcodeFingerprint));
  const actualPhoneRefs=Object.entries(actualPhones).map(([key,count])=>({ownerFingerprint:hash(key),count:number(count)})).sort((a,b)=>a.ownerFingerprint.localeCompare(b.ownerFingerprint));
  const expectedPhoneRefs=Object.entries(phones).map(([key,count])=>({ownerFingerprint:key,count})).sort((a,b)=>a.ownerFingerprint.localeCompare(b.ownerFingerprint));
  const daily=ledger((tree.zoew_daily_revenue_cod_dod||{})[day]), monthly=ledger((tree.zoew_monthly_revenue_cod_dod||{})[month]);
  const monthRows=Object.entries(tree.zoew_daily_revenue_cod_dod||{}).filter(([d])=>d.slice(0,7)===month).map(([,v])=>ledger(v));
  const targetRows=target?all.filter(row=>row.barcodeFingerprint===hash(String(target).trim().toUpperCase())):[];
  const expected={barcodeDerivedDaily:{cod:r2(cod),dod:r2(dod),revenueCount},
    dailyDerivedMonthly:{cod:r2(monthRows.reduce((s,r)=>s+r.cod,0)),dod:r2(monthRows.reduce((s,r)=>s+r.dod,0)),revenueCount:monthRows.reduce((s,r)=>s+r.revenueCount,0)},
    pickedUpPackages:packages,pickedUpCustomers:Object.keys(phones).length,ownerReferences:expectedPhoneRefs,pickupBarcodeIdentities:expectedPickupKeys,
    scriptedDaily:ctx.expectedDaily?{cod:number(ctx.expectedDaily.codDollar),dod:number(ctx.expectedDaily.dodDollar),revenueCount:number(ctx.expectedDaily.totalCount)}:null,
    scriptedMonthly:ctx.expectedMonthly?{cod:number(ctx.expectedMonthly.codDollar),dod:number(ctx.expectedMonthly.dodDollar),revenueCount:number(ctx.expectedMonthly.totalCount)}:null,
    target:ctx.expectedLocation?{location:ctx.expectedLocation,deducted:ctx.expectedDeducted===true,occurrences:1}:null};
  const actual={daily,monthly,pickup:{packages:number(pickup.packagesPickedUp),customers:Object.keys(actualPhones).length,
      ownerReferences:actualPhoneRefs,pickupBarcodeKeys:Object.keys(pickup.pickedUpBarcodes||{}).length,pickupBarcodeIdentities:actualPickupKeys},
    barcodes:{total:all.length,distinct:seen.size,history:all.filter(r=>r.location==='history').length,trash:all.filter(r=>r.location==='trash').length,
      deducted:all.filter(r=>r.deducted).length,duplicateIdentities:[...seen.values()].filter(n=>n>1).length,
      registryKeys:Object.values(registry).filter(v=>v===true).length,missingRegistry:all.filter(r=>!r.registryPresent).length,
      stateFingerprint:hash(JSON.stringify(all.sort((a,b)=>(a.barcodeFingerprint+a.location).localeCompare(b.barcodeFingerprint+b.location))))},
    rows:{history:values(tree.zoew_scan_history_cod_dod).length,trash:values(tree.zoew_recently_deleted_cod_dod).length},
    receipts:Object.keys(tree.zoew_write_receipts||{}).length,restoreFinalizations:Object.keys(tree.zoew_restore_finalizations||{}).length,target:targetRows};
  const totalsEqual=(got,want)=>!want || ['cod','dod','revenueCount'].every(k=>got[k]===want[k]);
  const comparisons={dailyMatchesBarcode:totalsEqual(daily,expected.barcodeDerivedDaily),monthlyMatchesDailySum:totalsEqual(monthly,expected.dailyDerivedMonthly),
    dailyMatchesScript:ctx.expectedDaily?totalsEqual(daily,expected.scriptedDaily):null,monthlyMatchesScript:ctx.expectedMonthly?totalsEqual(monthly,expected.scriptedMonthly):null,
    pickedPackagesMatch:actual.pickup.packages===packages,pickedCustomersMatch:actual.pickup.customers===Object.keys(phones).length,
    ownerReferencesMatch:JSON.stringify(actualPhoneRefs)===JSON.stringify(expectedPhoneRefs),pickupBarcodeIdentitiesMatch:JSON.stringify(actualPickupKeys)===JSON.stringify(expectedPickupKeys),
    targetMatchesScript:expected.target?targetRows.length===1 && targetRows[0].location===expected.target.location && targetRows[0].deducted===expected.target.deducted:null};
  return {schema:1,backend:ctx.backend,mode:ctx.mode,tenant:ctx.tenant,day,month,label:ctx.label,phase:ctx.phase,
    actual,expected,comparisons,expectationBasis:ctx.expectedDaily?'scripted financial deltas plus independently calculated server barcode/pickup identities':'independent server state oracle; no sequential business-effect expectation for concurrent fuzz',
    status:'OBSERVATION_NOT_ADDITIONAL_TEST',convergedCheckpoint:['checkpoint','converged-round','isolation-checkpoint'].includes(ctx.phase),production:false};
}
function createObserver(write) {
  const previous=new Map();let count=0;
  return Object.assign((ctx,tree)=>{
    const row=snapshot(ctx,tree),key=[ctx.backend,ctx.tenant,ctx.day].join('|'),old=previous.get(key);
    row.sequence=++count;
    row.previous=old?{sequence:old.sequence,label:old.label,daily:old.actual.daily,monthly:old.actual.monthly,pickup:old.actual.pickup,barcodes:old.actual.barcodes}:null;
    row.delta=old?{cod:r2(row.actual.daily.cod-old.actual.daily.cod),dod:r2(row.actual.daily.dod-old.actual.daily.dod),revenueCount:row.actual.daily.revenueCount-old.actual.daily.revenueCount,
      pickedUpPackages:row.actual.pickup.packages-old.actual.pickup.packages,pickedUpCustomers:row.actual.pickup.customers-old.actual.pickup.customers,
      historyBarcodes:row.actual.barcodes.history-old.actual.barcodes.history,trashBarcodes:row.actual.barcodes.trash-old.actual.barcodes.trash}:null;
    previous.set(key,row);write(JSON.stringify(row)+'\n');return row;
  },{count:()=>count});
}
module.exports={snapshot,createObserver};
