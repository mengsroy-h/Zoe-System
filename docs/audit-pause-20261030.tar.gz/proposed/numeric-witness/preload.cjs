'use strict';
// Run only against the selected local audit measure-root. Never writes tracked files.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const Module = require('node:module');
const OBSERVER = path.join(__dirname, 'observer.cjs');
const TAG = '/* ZOE_NUMERIC_OBSERVER */';
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
function transform(source, relative) {
  let output=source;
  const insert=(anchor,line)=>{
    if(output.split(anchor).length!==2)throw new Error('numeric instrumentation anchor is not unique: '+relative+' '+anchor.slice(0,100));
    output=output.replace(anchor,anchor+'\n'+TAG+' '+line);
  };
  insert("'use strict';",'const __numericWitness = globalThis.__zoeNumericWitness;');
  if(relative==='audit-tools/money-cookie-blob.js') {
    insert('    const initial = await read();',"__numericWitness({backend,mode:authMode,tenant:tag,label:'mode-start',phase:'baseline',day:dateKey,month:monthKey},initial);");
    insert('    const verify = async (label, code, where, deducted) => {\n        await sync();\n        const t = await read();',"__numericWitness({backend,mode:authMode,tenant:tag,label,phase:'checkpoint',day:scanDays.get(code)||dateKey,month:(scanDays.get(code)||dateKey).slice(0,7),targetCode:code,expectedLocation:where,expectedDeducted:deducted,expectedDaily:revenue.day(scanDays.get(code)||dateKey),expectedMonthly:revenue.month((scanDays.get(code)||dateKey).slice(0,7))},t);");
    insert('            const beforeAction = await read();',"__numericWitness({backend,mode:authMode,tenant:tag,label:label+'/'+a+'-'+wanted+'/before',phase:'before-action',day:scanDay,month:scanDay.slice(0,7),targetCode:code,expectedDaily:revenue.day(scanDay),expectedMonthly:revenue.month(scanDay.slice(0,7))},beforeAction);");
    insert('                const beforeStage = await read();',"__numericWitness({backend,mode:authMode,tenant:tag,label:flow+'/'+mode+'/'+stage+'/before',phase:'before-action',day:dateKey,month:monthKey,targetCode:code,expectedDaily:revenue.day(dateKey),expectedMonthly:revenue.month(monthKey)},beforeStage);");
    insert('                    const t = await read(); const rev = t.zoew_daily_revenue_cod_dod[dateKey];',"__numericWitness({backend,mode:authMode,tenant:tag,label:flow+'/'+mode+'/'+stage+'/offline',phase:'offline-before-reconnect',day:dateKey,month:monthKey,targetCode:code,expectedDaily:revenue.day(dateKey),expectedMonthly:revenue.month(monthKey)},t);");
    insert('            const claimed = await read();',"__numericWitness({backend,mode:authMode,tenant:tag,label:'sign-after-'+phase+'/claimed',phase:'restore-claim-or-prepared',day:dateKey,month:monthKey,targetCode:code,expectedDaily:revenue.day(dateKey),expectedMonthly:revenue.month(monthKey)},claimed);");
  } else if(relative==='audit-tools/emu/money-multidevice-emu-test.js') {
    insert('                const inv = invariant(dump || {}, dateKey, monthKey, knownCodes);',"__numericWitness({backend:'firebase',mode:'seeded-fuzz',tenant:'firebase-'+run,label:'run/'+run+'/round/'+i,phase:'converged-round',day:dateKey,month:monthKey},dump||{});");
  } else if(relative==='audit-tools/supabase-money-multishop-test.js') {
    insert('                const current = await Promise.all(neighbors.map((neighbor) => tree(neighbor.tenant)));',"neighbors.forEach((neighbor,index)=>__numericWitness({backend:'supabase',mode:'neighbor',tenant:'s'+neighbor.index,label:'neighbor/'+label,phase:'isolation-checkpoint',day:dateKey,month:monthKey},current[index]));");
    insert('                const t = await tree(shop.tenant);',"__numericWitness({backend:'supabase',mode:'seeded-fuzz',tenant:'s'+shop.index,label:'round/'+i+'/before',phase:'before-round',day:dateKey,month:monthKey},t);");
    insert('            const invs = shops.map((shop, k) => invariant(trees[k], dateKey, monthKey, shop.knownCodes));',"shops.forEach((shop,index)=>__numericWitness({backend:'supabase',mode:'seeded-fuzz',tenant:'s'+shop.index,label:'round/'+i+'/after',phase:'converged-round',day:dateKey,month:monthKey},trees[index]));");
  }
  const stripped=output.split('\n').filter(line=>!line.startsWith(TAG)).join('\n');
  if(stripped!==source)throw new Error('instrumentation changed non-observer source: '+relative);
  return output;
}
const targets=['audit-tools/money-cookie-blob.js','audit-tools/emu/money-multidevice-emu-test.js','audit-tools/supabase-money-multishop-test.js'];
function shouldActivate(root, entry) {
  return targets.filter(p=>p!=='audit-tools/money-cookie-blob.js').some(p=>path.resolve(root,p)===path.resolve(entry||''));
}
function safeObserver(observe,onError) {
  return (ctx,tree)=>{
    try { return observe(JSON.parse(JSON.stringify(ctx)),JSON.parse(JSON.stringify(tree))); }
    catch(error) { onError({kind:'observation-error',name:error?.name||'Error',message:String(error?.message||error).slice(0,300)});return null; }
  };
}
function start() {
  if(!process.env.ZOE_NUMERIC_ROOT || !process.env.ZOE_NUMERIC_OUTPUT_DIR) return;
  const root=path.resolve(process.env.ZOE_NUMERIC_ROOT), dir=path.resolve(process.env.ZOE_NUMERIC_OUTPUT_DIR);
  // Root/entry checks happen before any file writes or Module hook installation. Mutant shadows remain untouched.
  if(!root.startsWith('/workspace/') || !dir.startsWith('/workspace/zoe-audit-target-20261029/'))return;
  if(!shouldActivate(root,process.argv[1]))return;
  const backend=path.basename(process.argv[1]).startsWith('supabase-')?'supabase':'firebase';
  const file=path.join(dir,backend+'-'+process.pid+'.jsonl'),manifest=file+'.manifest.json';
  const metadata={schema:1,createdAt:new Date().toISOString(),root,entry:path.resolve(process.argv[1]),output:file,pid:process.pid,node:process.version,
    observerSha256:sha(fs.readFileSync(OBSERVER)),preloadSha256:sha(fs.readFileSync(__filename)),modules:[],assertionsChanged:false,additionalDatabaseReads:0,observations:0,errors:[]};
  const recordError=error=>metadata.errors.push(error);
  let fd;
  try { fs.mkdirSync(dir,{recursive:true,mode:0o700});fd=fs.openSync(file,'wx',0o600); }
  catch(error) { console.error('NUMERIC_WITNESS_SETUP_FAILED '+error.name);return; }
  for(const relative of ['audit-tools/money-multidevice-core.js','ZoeW/app.js']) {
    try { metadata[relative==='ZoeW/app.js'?'appBundleSha256':'oracleSourceSha256']=sha(fs.readFileSync(path.join(root,relative))); }
    catch(error) { recordError({kind:'provenance-read',relative,name:error.name}); }
  }
  const observe=require(OBSERVER).createObserver(line=>fs.writeSync(fd,line));
  globalThis.__zoeNumericWitness=safeObserver(observe,recordError);
  const original=Module._extensions['.js'];
  Module._extensions['.js']=function(mod,filename){
    const relative=path.relative(root,filename).split(path.sep).join('/');
    if(!targets.includes(relative))return original(mod,filename);
    let source,instrumented;
    try {
      source=fs.readFileSync(filename,'utf8');instrumented=transform(source,relative);
      // Compile-only validation precedes execution; an invalid observer falls back before any module side effects.
      new (require('node:vm').Script)(Module.wrap(instrumented),{filename});
      metadata.modules.push({relative,originalSha256:sha(source),instrumentedSha256:sha(instrumented),observerInsertions:instrumented.split(TAG).length-1});
    } catch(error) { recordError({kind:'instrumentation-setup',relative,name:error.name,message:String(error.message).slice(0,300)});return original(mod,filename); }
    return mod._compile(instrumented,filename);
  };
  process.on('exit',code=>{
    metadata.observations=observe.count();metadata.checkerExitCode=code;
    metadata.moduleCoverageComplete=metadata.modules.some(m=>m.relative==='audit-tools/money-cookie-blob.js')&&metadata.modules.length>=2;
    if(!metadata.observations || !metadata.moduleCoverageComplete)recordError({kind:'incomplete-witness',message:'No authoritative observations or required modules missing'});
    metadata.witnessStatus=metadata.errors.length?'PARTIAL_OR_FAILED':'COLLECTED_NOT_YET_ANALYZED';
    // Preserve checker exit code. A broken observer makes witness evidence incomplete, never turns a checker result green.
    try { fs.closeSync(fd);fs.writeFileSync(manifest,JSON.stringify(metadata,null,2)+'\n',{flag:'wx',mode:0o600}); }
    catch(error) { console.error('NUMERIC_WITNESS_MANIFEST_FAILED '+error.name); }
  });
}
module.exports={transform,targets,shouldActivate,safeObserver};
if(process.env.ZOE_NUMERIC_NO_START!=='1') start();
