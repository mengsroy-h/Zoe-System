'use strict';
process.env.ZOE_NUMERIC_NO_START='1';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),Module=require('node:module');
const {snapshot,createObserver}=require('./observer.cjs');
const {transform,targets,shouldActivate,safeObserver}=require('./preload.cjs');
const root='/workspace/Zoe-System-target';
const {invariant,invariantBroken}=require(root+'/audit-tools/money-multidevice-core.js');
const {createRevenueExpectation}=require(root+'/audit-tools/money-cookie-blob.js');
const day='2026-10-29',month='2026-10',codes=['AA','BB','CC','DD'];
const item=(id,phone,codes,closed)=>({id,phone,scanDate:day,barcodes:codes.map(code=>({code,cod:1.25,dod:0.5,isClosed:closed,isDeducted:false}))});
const fixture=()=>({zoew_scan_history_cod_dod:{a:item('a','012345678',['AA','BB'],true),b:item('b','098765432',['CC'],true),c:item('c','011223344',['DD'],false)},zoew_recently_deleted_cod_dod:{},zoew_barcode_registry:{AA:true,BB:true,CC:true,DD:true},zoew_daily_revenue_cod_dod:{[day]:{codDollar:5,dodDollar:2,totalCount:4}},zoew_monthly_revenue_cod_dod:{[month]:{codDollar:5,dodDollar:2,totalCount:4}},zoew_daily_pickup_cod_dod:{[day]:{packagesPickedUp:3,pickedUpPhones:{'012345678':2,'098765432':1},pickedUpBarcodes:{AA:'012345678',BB:'012345678',CC:'098765432'}}}});
let passed=0;const check=(name,fn)=>{fn();passed++;console.log('PASS '+name);};
check('all three original runner/harness files remain byte-identical after stripping observer lines',()=>{
 for(const relative of targets){const source=fs.readFileSync(path.join(root,relative),'utf8'),next=transform(source,relative);new vm.Script(Module.wrap(next));assert.equal(next.split('\n').filter(l=>!l.startsWith('/* ZOE_NUMERIC_OBSERVER */')).join('\n'),source);}
});
check('exact entry allowlist rejects guardian, helper-only and mutant shadow',()=>{
 assert.equal(shouldActivate(root,path.join(root,targets[1])),true);assert.equal(shouldActivate(root,path.join(root,targets[2])),true);
 assert.equal(shouldActivate(root,path.join(root,targets[0])),false);assert.equal(shouldActivate(root,path.join(root,'audit-tools/money-guardian-test.js')),false);assert.equal(shouldActivate(root,path.join(root,'mutant-shadow',targets[1])),false);
});
const ctx={backend:'synthetic',mode:'control',tenant:'s0',label:'baseline',phase:'checkpoint',day,month,expectedDaily:{codDollar:5,dodDollar:2,totalCount:4},expectedMonthly:{codDollar:5,dodDollar:2,totalCount:4}};
check('independent numeric witness: COD5/DOD2/count4, pickup packages3/customers2',()=>{
 const tree=fixture(),prior=structuredClone(tree),row=snapshot(ctx,tree);assert.deepEqual(tree,prior);assert.equal(row.actual.daily.cod,5);assert.equal(row.actual.pickup.packages,3);assert.equal(row.actual.pickup.customers,2);assert.equal(row.expected.pickedUpPackages,3);assert.equal(row.expected.pickedUpCustomers,2);assert.ok(Object.values(row.comparisons).every(v=>v===null||v===true));
 assert.equal(JSON.stringify(row).includes('012345678'),false);assert.equal(JSON.stringify(row).includes('098765432'),false);
});
for(const [name,mutate] of [
 ['wrong ledger',t=>{t.zoew_daily_revenue_cod_dod[day].codDollar=7;}],
 ['wrong pickup packages',t=>{t.zoew_daily_pickup_cod_dod[day].packagesPickedUp=4;}],
 ['wrong customer ownership with same totals',t=>{t.zoew_daily_pickup_cod_dod[day].pickedUpPhones={'012345678':1,'098765432':2};}],
 ['wrong pickup barcode identity with same count',t=>{delete t.zoew_daily_pickup_cod_dod[day].pickedUpBarcodes.AA;t.zoew_daily_pickup_cod_dod[day].pickedUpBarcodes.DD='012345678';}],
 ['duplicate history/trash barcode',t=>{t.zoew_recently_deleted_cod_dod.copy=structuredClone(t.zoew_scan_history_cod_dod.c);}],
 ['missing registry barcode',t=>{delete t.zoew_barcode_registry.DD;}]
])check('negative control remains failed after observing: '+name,()=>{
 const t=fixture();mutate(t);const before=structuredClone(t),why=invariantBroken(invariant(t,day,month,codes));assert.ok(why);safeObserver(createObserver(()=>{}),e=>{throw new Error(JSON.stringify(e));})(ctx,t);assert.deepEqual(t,before);assert.equal(invariantBroken(invariant(t,day,month,codes)),why);
});
check('scripted financial oracle still rejects matching wrong barcode and ledger',()=>{
 const baseline=fixture(),expected=createRevenueExpectation(baseline),bad=fixture();bad.zoew_scan_history_cod_dod.c.barcodes[0].cod=0;bad.zoew_daily_revenue_cod_dod[day].codDollar=3.75;bad.zoew_monthly_revenue_cod_dod[month].codDollar=3.75;
 assert.equal(invariantBroken(invariant(bad,day,month,codes)),null);assert.throws(()=>expected.verify(bad,codes,'negative'));
 const row=snapshot(ctx,bad);assert.equal(row.comparisons.dailyMatchesScript,false);assert.throws(()=>expected.verify(bad,codes,'negative after observation'));
});
check('observer output failure is contained and cannot suppress original invariant failure',()=>{
 const errors=[],t=fixture();t.zoew_daily_revenue_cod_dod[day].codDollar=99;
 const observed=safeObserver(createObserver(()=>{throw new Error('synthetic disk full');}),e=>errors.push(e));assert.doesNotThrow(()=>observed(ctx,t));assert.equal(errors.length,1);assert.ok(invariantBroken(invariant(t,day,month,codes)));
});
check('observer clones caller input before passing it to observation code',()=>{
 const t=fixture(),prior=structuredClone(t),errors=[];safeObserver((_ctx,copy)=>{copy.zoew_scan_history_cod_dod={};},e=>errors.push(e))(ctx,t);assert.deepEqual(t,prior);assert.equal(errors.length,0);
});
check('sequential numeric delta links exact previous actual snapshot',()=>{
 const lines=[],obs=createObserver(l=>lines.push(JSON.parse(l))),t=fixture();obs(ctx,t);t.zoew_scan_history_cod_dod.c.barcodes[0].isDeducted=true;t.zoew_daily_revenue_cod_dod[day]={codDollar:3.75,dodDollar:1.5,totalCount:3};t.zoew_monthly_revenue_cod_dod[month]={codDollar:3.75,dodDollar:1.5,totalCount:3};obs({...ctx,label:'deduct'},t);assert.equal(lines[1].previous.sequence,1);assert.equal(lines[1].delta.cod,-1.25);assert.equal(lines[1].delta.dod,-0.5);assert.equal(lines[1].delta.revenueCount,-1);assert.equal(lines[1].delta.pickedUpCustomers,0);
});
console.log(JSON.stringify({passed,failed:0,backendExecution:false,sourceChanged:false}));
