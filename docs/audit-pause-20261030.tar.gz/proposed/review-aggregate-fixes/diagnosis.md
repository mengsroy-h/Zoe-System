# Aggregate purity and lookup failure diagnosis

Frozen base27f00719aa59645b1b74d083d3ac7da0019113f5; EXTERNAL proposals only, no runtime rerun while aggregate is active.

## Purity

`logs/purity-failure-detail.log`:14 checks PASS/1 FAIL, one `.append()` in `services/scan-pending.ts:38`. The guard at `scripts/react-purity-check.mjs:149` classifies calls by method name and does not inspect receiver type. This receiver is `createScanEvidenceJournal(appLocalStore)`, whose method writes immutable localStorage phase evidence (`services/scan-evidence.ts:131`); no DOM is involved. Proposed `appendPhase` rename covers the new utility API, its single production caller, and all unit callsites. No guard/allowlist/ceiling change; storage schema, keys and phase values unchanged. External `pending-evidence-perf.cjs` needs the accompanying caller patch only after source rename. Repository callsite search found no other journal `.append` use; mutation-runner anchors remain unaffected.

## Lookup

`raw-verification/runs/zoe-runall.RWA51g/199.out` lists12 failing lookup cases and an unhandled deferred `h.claim.reject(new Error('net'))`. Fixture `beforeEach` supplies `db={name}`, `fb.ref`, but neither logged-in UID nor live/saved project identity. `pendingScanScope()` requires both UID and `liveShopScope()`; `preparePendingScan()` therefore throws before `claimBarcodeInRegistry` at `scan-action.ts:176–179`. It immediately clears busy in finally, so late lookup answers follow the wrong idle branch and claims never execute. An unused deferred reject explains the unhandled rejection; hiding that rejection would mask fixture breakage.

Proposed setup supplies realistic `db.app.options.databaseURL`, matching `auth.app.options`, `auth.currentUser.uid`, saved Firebase config and initialization=false. It does not mock/skip durable admission and does not modify any test body, claim expectation, save/success expectation, duplicate guard or ZTO money warning assertion. Existing separate scan-pending tests already verify missing UID/scope rejection; this fixture represents a logged-in active app.

Status: root-cause source trace and existing failing aggregate evidence only. Focused lookup/unit/purity execution after aggregate is required; do not call the proposals green before that run. If additional failures remain, investigate independently instead of weakening expectations. Another agent has been asked for independent proposal review.
