'use strict';
// Distinct bounded queue workload; uses the frozen checker's own synthetic app/server helpers.
const fs = require('fs'), path = require('path'), cp = require('child_process'), crypto = require('crypto');
const EVIDENCE = '/workspace/zoe-audit-target-20261029';
const ROOT = process.env.PERF_APP_DIR || '/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root';
const LABEL = process.env.ZOE_VERIFICATION_LABEL || 'verification';
const ORDERS = Number(process.env.PENDING_PERF_ORDERS || 1200);
const SAMPLES = 50, LISTENER_SAMPLES = 20, BOOT_SAMPLES = 20;
const OUTPUT = path.join(EVIDENCE, LABEL + '-pending-perf.json');
if (fs.existsSync(OUTPUT)) throw new Error('Refuse to overwrite evidence: ' + OUTPUT);
cp.execFileSync('python3', [path.join(EVIDENCE, 'verify-load-readiness.py'), LABEL], {stdio: 'inherit'});
process.env.PERF_CHROME = '/usr/bin/chromium';
const helperFile = path.join(ROOT, 'audit-tools/perf-check.js'), helperSource = fs.readFileSync(helperFile, 'utf8');
const marker = '\n(async () => {';
if (helperSource.split(marker).length !== 2) throw new Error('Perf helper boundary changed');
const helperPrefix = helperSource.slice(0, helperSource.indexOf(marker));
const {chromium, serve, BOOT, seedBig, LICENSE_STUB} = new Function('require', '__dirname', helperPrefix + '\nreturn {chromium,serve,BOOT,seedBig,LICENSE_STUB};')(require, path.dirname(helperFile));
if (!chromium || !fs.existsSync(process.env.PERF_CHROME)) throw new Error('Browser prerequisite absent');
const percentile = (values, p) => [...values].sort((a,b)=>a-b)[Math.min(values.length-1,Math.ceil(values.length*p)-1)];
const distribution = (values) => ({n:values.length,p50:percentile(values,.50),p95:percentile(values,.95),p99:percentile(values,.99),max:Math.max(...values),raw:values});
const report = {
  status:'RUNNING',startedAt:new Date().toISOString(),label:LABEL,orders:ORDERS,
  sources:{helperSha256:crypto.createHash('sha256').update(helperSource).digest('hex')},
  storage:'Actual Chromium localStorage, real exported scan-evidence factory and scan-pending warning',
  phases:['prepared','claim-pending','claimed','save-pending','pending'],
  limits:{pendingRecords:200,bytes:512*1024},samples:{list:SAMPLES,warning:SAMPLES,listener:LISTENER_SAMPLES,reloadReadiness:BOOT_SAMPLES},
  limitations:['Synthetic Firebase SDK/auth transport, no real network or production capacity claim','Listener measurement ends after debounced history render sequence and two animation frames; asynchronous cleanup jobs are not full sync convergence','p99 of 20 samples is the maximum observed and has limited statistical precision','Raw timing includes journal verification and browser storage overhead; setup is timed separately'],workloads:[]
};
const save = () => fs.writeFileSync(OUTPUT,JSON.stringify(report,null,2)+'\n');
let browser,server;
(async () => {
  browser=await chromium.launch({executablePath:process.env.PERF_CHROME});
  server=await serve(path.join(ROOT,'ZoeW'));const port=server.address().port,url='http://127.0.0.1:'+port+'/';
  const context=await browser.newContext({viewport:{width:412,height:780}}), page=await context.newPage();
  page.on('dialog',d=>d.accept());
  const pageErrors=[];page.on('pageerror',e=>pageErrors.push(String(e)));
  await page.route('**',r=>{const u=r.request().url();if(u.includes('/license-verify.js'))return r.fulfill({status:200,contentType:'application/javascript',body:LICENSE_STUB});if(u.startsWith(url))return r.continue();return r.abort();});
  const seed=seedBig(ORDERS);
  await page.addInitScript(`localStorage.setItem('zoew_firebase_config',${JSON.stringify(JSON.stringify({apiKey:'k',databaseURL:'https://fake-default-rtdb.firebaseio.com',projectId:'p'}))});`);
  await page.addInitScript('('+BOOT.toString()+')('+JSON.stringify(seed)+');');
  const ready = async () => {
    await page.waitForFunction(() => typeof window.createScanEvidenceJournal==='function' && typeof window.pendingScanScope==='function' && window.pendingScanScope() && window.uiState && Number(window.uiState.historyRenderSeq)>0 && document.querySelectorAll('#historyTableBody tr').length>5,null,{timeout:30000});
    await page.evaluate(() => new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  };
  await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});await ready();
  const cdp=await context.newCDPSession(page);await cdp.send('Performance.enable');
  for(const requested of [0,50,100,200]) {
    const before=await cdp.send('Performance.getMetrics');
    const setup=await page.evaluate(requested=>{
      const prefix='zoew_scan_evidence_v1:';
      for(const key of Object.keys(localStorage).filter(k=>k.startsWith(prefix)))localStorage.removeItem(key);
      const journal=window.createScanEvidenceJournal(localStorage),scope=window.pendingScanScope(),start=performance.now();
      let completed=0,limitError=null;
      for(let i=0;i<requested;i++) {
        try {
          const record=journal.prepare(scope,{barcode:'PENDING_PERF_'+i,createdAt:Date.now(),cod:5,dod:0,scanDate:window.getFormattedDate(),mode:'perf'});
          journal.appendPhase(record,{phase:'claim-pending'});journal.appendPhase(record,{phase:'claimed'});
          journal.appendPhase(record,{phase:'save-pending',itemId:'pending_perf_'+i});journal.appendPhase(record,{phase:'pending'});completed++;
        } catch(e) {limitError={code:e.code,message:String(e.message)};break;}
      }
      const keys=Object.keys(localStorage).filter(k=>k.startsWith(prefix));
      const rows=journal.list(scope);
      return {requested,completed,actualPending:rows.length,limitError,setupMs:performance.now()-start,keys:keys.length,bytes:keys.reduce((n,k)=>n+2*(k.length+localStorage.getItem(k).length),0),phases:rows.reduce((o,r)=>(o[r.phase]=(o[r.phase]||0)+1,o),{})};
    },requested);
    const row={...setup,status:'RUNNING',before};report.workloads.push(row);save();
    if(setup.actualPending<Math.min(requested,100)||setup.actualPending>200||setup.bytes>512*1024)throw new Error('Unexpected setup bounds '+JSON.stringify(setup));
    const boots=[];
    for(let i=0;i<BOOT_SAMPLES;i++){const start=performance.now();await page.reload({waitUntil:'domcontentloaded',timeout:30000});await ready();boots.push(performance.now()-start);}
    row.reloadReadinessMs=distribution(boots);
    const timings=await page.evaluate(async ({samples,listenerSamples,expected})=>{
      const journal=window.createScanEvidenceJournal(localStorage),scope=window.pendingScanScope();
      const snapshot=()=>Object.keys(localStorage).filter(k=>k.startsWith('zoew_scan_evidence_v1:')).sort().map(k=>[k,localStorage.getItem(k)]);
      const original=JSON.stringify(snapshot());const list=[],warning=[],listener=[];
      for(let i=0;i<samples;i++){
        let start=performance.now();const rows=journal.list(scope);list.push(performance.now()-start);if(rows.length!==expected)throw new Error('Pending rows changed');
        start=performance.now();window.warnPendingScans();warning.push(performance.now()-start);
      }
      for(let i=0;i<listenerSamples;i++){
        const before=window.uiState.historyRenderSeq,start=performance.now();
        await new Promise((resolve,reject)=>{
          let stop;const timer=setTimeout(()=>{if(stop)stop();reject(new Error('No debounced history render within 5000ms'));},5000);
          stop=window.uiState.subscribe(()=>{if(window.uiState.historyRenderSeq<=before)return;stop();clearTimeout(timer);requestAnimationFrame(()=>requestAnimationFrame(resolve));});
          window.__fireHistory();
        });
        listener.push(performance.now()-start);
        if(window.__listenerThrew)throw new Error(window.__listenerThrew);
      }
      const unchanged=original===JSON.stringify(snapshot());
      if(!unchanged)throw new Error('Read/listener workload mutated pending evidence');
      return {list,warning,listener,pendingUnchanged:unchanged};
    },{samples:SAMPLES,listenerSamples:LISTENER_SAMPLES,expected:setup.actualPending});
    row.listMs=distribution(timings.list);row.warningMs=distribution(timings.warning);row.listenerToRenderedUiMs=distribution(timings.listener);row.pendingUnchanged=timings.pendingUnchanged;
    row.after=await cdp.send('Performance.getMetrics');row.status='MEASURED';save();
    console.log('PENDING_PERF '+JSON.stringify({requested,actualPending:row.actualPending,bytes:row.bytes,listMs:{...row.listMs,raw:undefined},warningMs:{...row.warningMs,raw:undefined},listenerToRenderedUiMs:{...row.listenerToRenderedUiMs,raw:undefined},reloadReadinessMs:{...row.reloadReadinessMs,raw:undefined},limitError:row.limitError}));
  }
  report.pageErrors=pageErrors;if(pageErrors.length)throw new Error('Browser page errors observed');
  report.status='MEASURED';report.finishedAt=new Date().toISOString();save();
  await context.close();
})().catch(e=>{report.status='FAILED';report.error=String(e&&e.stack||e);save();console.error(report.error);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));});
