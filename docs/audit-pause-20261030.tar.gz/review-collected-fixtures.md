# ពិនិត្យ assertions ក្រោយ cleanup/pickup protocol

Scope: `ZoeW/tests/collected-mirror-durable.test.ts`, ប្រៀបធៀប WIP HEAD `43ad59f00a93441fb95636e61375a19a689005be` ជាមួយ working tree។ Reviewer អាន diff និង production contract; មិនកែ tracked files និងមិនរត់ heavy suite ក្នុងជុំនេះ។

សេចក្ដីសម្រេច៖ **APPROVED សម្រាប់ test changes បន្ទាប់ពីការពង្រឹងខាងក្រោម**។ Final `root-collected-v2-complete.json` មាន110 PASS/0 FAIL/0 SKIP។ Earlier109 PASS/1 FAIL គឺ owner-release regression; assertion ថា old live owner ត្រូវ release ក្រោយ Reconfig ត្រូវបានរក្សា និង source ត្រូវបានកែឱ្យឆ្លង។ Expected-capacity-refusal tests ប្រើ direct prepare→null; known-success helper មិនត្រូវបានបន្ថយ assertions ទេ។

| ការប្រែ assertion | វិនិច្ឆ័យ |
|---|---|
| Foreign scope: លុប journal + Sentry → រក្សា bytes/stage/outcome ដដែល និងគ្មាន backend write | ស្រប contract ថ្មី។ ការរក្សាទិន្នន័យត្រូវបានផ្ទៀងដោយ snapshot bytes និង DB ពេញ។ គ្មានការបន្ថយ expected money arrays។ Alarm សម្រាប់ការបោះបង់ដែលមិនបានធ្វើ មិនគួរផ្ញើ។ |
| Legacy v1: សន្និដ្ឋាន `unverified`/លុប mirror → HOLD ដោយមិនប្ដូរ raw v1, mirror, pickup ឬ DB | ស្របការបំបែក legacy ដែលគ្មាន epoch/actor proof។ Assertions ថ្មីផ្ទៀង zero mutation និងមិនបកស្រាយ legacy ជា operation ថ្មី។ នេះជាការផ្លាស់ប្ដូរ recovery contract ដោយចេតនា មិនមែនគ្រាន់តែប្ដូរ storage fixture។ |
| New mirror refusal: retry ceiling លុប journal → HOLD ហើយស្តារបានពេល mirror ACK | រក្សា `[96,9,9]` ការដកប្រាក់តែម្តង។ បន្ថែម positive recovery ក្រោយដោះ fault និង `actualMirror()===expectedMirror()`។ |
| Lost ACK: mirror repaired → journal នៅ HOLD | Actual close path នៅតែ execute។ ការអាន closed history មិនបញ្ជាក់ថា operation នេះបានបង្កើត transition មុន Reset ទេ។ Test រក្សា mirror oracle និងពិនិត្យថា `transitionKnown` មិនបានប្រកាសដោយស្មាន។ |
| Capacity/clock: បណ្តេញ pending ចាស់ → បដិសេធ operation ថ្មី | ស្រប fail-closed admission; live និង unresolved records មិនបាត់។ |
| Metadata ថ្មីលើ Reset | Reviewer រកឃើញថា `toMatchObject({packagesPickedUp:0,pickupResetEpoch:1})` តែឯងធ្វើឱ្យ emptiness assertion ខ្សោយ។ Root បានបន្ថែម `pickedUpBarcodes` និង `pickedUpPhones` ទទេដោយ normalize ក្នុងគ្រប់ករណីនេះ។ |
| Known-transition fixture | Reviewer រកឃើញ helper អាច return null និងមិនពិនិត្យ start/confirm។ Root ប្ដូរឈ្មោះទៅ `seedConfirmedPickupIntent` និង assert prepare/start/confirm ទាំងបី។ Actual unknown-ACK cases មិនប្រើ helper នេះដើម្បីលាក់ HOLD ទេ។ |

Expected revenue values, real history/barcode state, mirror oracle និង stale-session no-write checks រក្សាទុក។ ការដក Sentry batching assertions សម្រាប់ foreign-scope drop មានហេតុផល ព្រោះ drop នោះលែងជាសកម្មភាពត្រឹមត្រូវ។ Active operation session-switch alarm ដែលចាំបាច់នៅតែមាន assertions របស់វា; ការបោះបង់ journal មិនត្រូវយកជាភស្តុតាងជោគជ័យ។

Docs gate: active `CLAUDE.md` Pickup stats, Late commit និង scan-settle contracts ត្រូវបានកែទៅ v2/legacy HOLD, scoped retention និង exact-identity/compensation-proof behavior។ HISTORY A445–A456 កត់ការផ្លាស់ប្ដូរ និង partial limits; A417–A444 រក្សាដដែល។

## VM fixture review បន្ថែម

បានអាន diff របស់ `late-commit-test.js`, `partial-pickup-cleanup-test.js`, `db-stall-guard-test.js`, `stall-lock-release-test.js`, `ledger-count-integrity-test.js`។ គ្មាន money/count/lock assertions ត្រូវលុប ឬ filter/skip បន្ថែម។ Actual protocol module bindings, storage enumeration, config/UID និង pickup backend store ដាច់ពី history គឺការកែ fixture ត្រឹមត្រូវ។ No-op pickup tracker ត្រូវបានដក។

Agent evidence193 PASS/5 processes គឺ bounded overlay compatibility ក្នុង `vm-five-checkpoint.md/json`; វាមិនមែន full production build ឬ real backend matrix ទេ។ Old checker RED បញ្ជាក់ missing fixture contract មិនមែន production defect ថ្មី។ Final aggregate នៅរង់ចាំ root source freeze។

## Final read-only gate — 2026-10-29T23:24:42.783394+00:00

**APPROVED សម្រាប់ checkpoint និង final aggregate។ នេះមិនមែន full-suite/release PASS ទេ។** User base `b0a67e915e61e6b8c8e4bc06a435c86742e45fa0`, current HEAD `43ad59f00a93441fb95636e61375a19a689005be` + local changes; tracked diff SHA256 `7465300c5b8050c7541d3594bf1e72199759cdc3d9bfc0957583bcf15b9a5e0d`។ ភស្តុតាង/កំណត់ hash ពេញនៅ `review-final-gate.json` និង `overlap-preservation.json`។

- User paths135:82 byte-identical +53 intentionally touched;0 missing/0 user tracked deletion។ A417–A444 ទាំង28 rows នៅដដែល; A445–A456 បន្ថែម។ `docs/AUDIT-WIP-CHECKPOINT.md` ដែលលុបគឺឯកសារបង្កើតក្នុង audit នេះ; facts បានបញ្ចូលក្នុង HISTORY និងនៅក្នុង Git history, មិនមែន user file នៅ b0 ទេ។
- Current actual Firebase SDK/rules browser pickup5 PASS (`review-pickup-rtdb-browser-green.json`), actual Supabase adapter/local PostgreSQL4 PASS with identical before/after inputs (`resume-pickup-client-pg-frozen-inputs.json`), current cleanup storage9 PASS (`review-cleanup-storage-frozen.json`)។ Source hashes ត្រូវគ្នានឹង working tree ចុងក្រោយ។ Cleanup hash `0d6d87bff47213e2dc82fc9ba875cb0bbebc18e60c07337987c60cbe6aca3991` រួមបញ្ចូល owner-release fix;773ee snapshot ខាងលើគឺ intermediate evidence។
- Root collected suite110 PASS/0 FAIL/0 SKIP (`root-collected-v2-complete.json`)។ Old owner must release assertion បានរក្សា ហើយ source fix ឆ្លង។ Expected-capacity-refusal controls ប្រើ direct prepare→null; known-transition helper នៅតែ assert prepare/start/confirm។ Reset zero-count controls ក៏ assert maps ទទេ។
- Active CLAUDE contracts ឥឡូវពិពណ៌នា per-entry v2/legacy HOLD, foreign-scope preservation, exact createdAt + latched unknown evidence, final committed transition proof និង compensation ACK មុន registry release។ HISTORY កត់ rules-first prerequisite និង partial scan recovery ដោយមិនសរសេរឡើងវិញប្រវត្តិចាស់។ Both staged/unstaged diff whitespace checks PASS។

Focused counts មាន overlap មិនត្រូវបូកជាចំនួនតេស្ត aggregate ទេ។ Actual RTDB pickup probe មាន stub mirror/UI seams; PG proof មិនតេស្ត HTTP/GoTrue/realtime; cleanup storage race ប្រើ separate VM contexts និង synthetic localStorage។ No live ZTO/production/real-mobile/SW-upgrade claim។ Full business scan crash reconciliation នៅ PARTIAL; journal HOLD មិនស្មើ automatic repair។ Root final aggregate (រួម final CRUD fixture), final commit/publication gate នៅរង់ចាំ។ គ្មាន tracked edits, push ឬ production action ដោយ reviewer។

ស្ថានភាព final នេះ supersedes chronological pending/intermediate snapshots ខាងលើ។

## Committed checkpoint gate — 2026-10-29T23:26:11.906850+00:00

Reviewed checkpoint is now **`27f00719aa59645b1b74d083d3ac7da0019113f5`**, clean working tree. Prior43ad labels above identify preserved intermediate evidence; current frozen source hashes in `review-final-gate.json` match the focused evidence unchanged. User-base diff SHA256 `dd84955e8429c8806b2aa9df36e1dd11a36c383ad9c6b5528137ebd5693bdc4e`; parent-reported frozen-input digest `dd071fa1904b00bc6e4f2b3edd310a4450064f1c176fe91c40481a6f961ff21f` is a separate manifest digest. Preservation remains135 paths /82 identical /53 intentionally touched, all28 A417–A444 rows exact, no user deletion.

Late `audit-tools/emu/crud-rules-flow.js` diff **APPROVED**: no assertions removed, weakened or filtered; fail exit/count and emulator strict-mode guards unchanged. Actual pickup/cleanup/storage/scope module views now retain private state/live bindings and reject missing/mismatched source. Real helper dependencies replace no-op tracker/commit/reapply/heal fixtures. Storage enumerates keys and sandbox supplies actual scope/UID shape. The blocked-remove/restore-claim fixture seeds an already fenced empty pickup day, explicitly separating initialization from its unchanged zero-write/zero-money assertions; it does not claim to test first-use initialization in that scenario. CRUD fixture SHA256 `4c7eb37d6e8188a27befdbba5dbebd7871225cc8cd3dcb85fc447229e1345295`, existing log160 PASS/0 FAIL. This reviewer did not rerun it.

**Final aggregate is RUNNING**, not yet PASS. No tracked edits, rebuilds or heavy tests performed in this gate. Approval remains checkpoint/aggregate review, with production/live-device/complete-reconciliation limits unchanged.
