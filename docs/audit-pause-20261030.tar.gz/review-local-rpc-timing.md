# Independent local RPC timing observer review

> Final follow-up: revised observer APPROVED; the original HOLD below is preserved failure evidence. No scale or full-suite PASS is implied.

Reviewed 2026-10-29T23:35:14.461837+00:00, preload SHA256 `aac090196c5c70b2a612e0a3c229cb3573228946065e486cd5ca307475137e9a`. Read-only source review; no tests, load, rebuild or tracked changes. Actual entry/fake hashes match the allowlist.

Decision: **HOLD for observer failure-isolation fix** before attachment to later scale runs. The parent aggregate remains running with an observed failure under investigation; this review supplies no full-suite PASS.

## Concrete finding

`activate()` writes the hash-mismatch NOT MEASURED report with uncaught `fs.writeFileSync` (line128 in this snapshot). An output path created after the exists check, permission loss or other I/O failure can throw during preload and prevent the original checker from starting. The exit listener also performs memory/summary/resource/hash computation outside its final write catch (lines138–147); an instrumentation exception can change process exit behavior. The periodic sampling callback is not isolated either. Guard the entire observer-only activation/sampling/report path, retain the original checker execution/exit, and mark missing/broken observer evidence unavailable. Requested targeted failure-isolation controls from backend owner; existing12 controls do not exercise these paths.

## Accepted review points

- Exact main entry/configured entry plus entry/fake SHA allowlist, scoped fake-module HTTP import, and bound/local/remote loopback checks constrain interception. Other HTTP consumers retain their original module.
- No auth headers, cookies, request/response bodies or query strings are logged. Samples contain only known RPC endpoint, HTTP status and duration. Current server routes and allowlist are synthetic local harness inputs.
- Request-event→finish latency, premature close status0, finish/close deduplication, complete status counters and nearest-rank quantiles are coherent. HTTP error rate excludes early closes and reports those separately; 401/403 are not claimed as expected denials. HTTP200 application errors are explicitly unclassified.
- First100000 retained samples bound memory; totals continue after truncation and limits disclose quantile bias. Small-sample p99, injected faults, event-listener overhead, no client acknowledgement/convergence proof, parent-only CPU/RSS and SIGKILL loss are documented.
- Selfcheck12 PASS is observer-only with a stub SQL pool and must not be relabelled database or production capacity evidence.

Scope clarification: attaching request/response listeners adds bounded observation work to the measured server path; overhead is included. This instrument does not measure full UI actions, PostgreSQL/Chromium process resources, or end-to-end sync convergence.

## Revised observer approved — 2026-10-29T23:52:57.842998+00:00

Current preload SHA256 `a7b23d6dda2c99595102e53173901e0e990abe65d73525a0a00e1a6b1b6bb127`. Read-only inspection confirms activation/output I/O, periodic memory sampling, entire exit report construction and server attachment failures are now isolated. Diagnostics avoid raw error objects and report NOT AVAILABLE/PARTIAL; missing output is not a measurement. Normal application callbacks and intended exit semantics remain intact.

Existing failure-injection evidence: `local-rpc-timing-failure-baseline.json`1 PASS/8 FAIL → `local-rpc-timing-failure-fixed.json`9 PASS/0 FAIL. Controls require the underlying assertion marker and later exit listener, preserve intended exit0/7, and verify timer callback continuation. Existing endpoint/count/quantile/leak-sentinel selfcheck remains12 PASS/0 FAIL. These subprocess/HTTP-stub controls are not database load or performance tests. Reviewer did not execute any test in this follow-up.

Decision: **APPROVED for the later bounded measurement** after parent releases resources. Backend must refresh `local-rpc-timing-inputs.json` (which still listed the earlier hash at review time) and documentation; scale results remain NOT RUN. The current product aggregate has observed failures under investigation, so no final correctness PASS is implied.
