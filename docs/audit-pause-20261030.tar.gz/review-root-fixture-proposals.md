# Root fixture proposals — independent static review

APPROVED for application and focused verification after aggregate freeze ends. Reviewed against27f00719; no product or assertion edits performed by reviewer.

- `three-device-recovery.patch`: fixture identity now supplies saved config and db.app.options, matching the real scope contract. It only seeds a missing config; an existing incompatible config fails an assertion instead of being overwritten. Rebooted device A keeps UID A and durable localStorage. No money/barcode/lock/negative-control assertion changes. Adding config cannot restore a deliberately erased business journal.
- `compat-paths-gone.patch`: the original expectation that irrelevant top-level barcode/closedAt differences do not invalidate a cleanup claim stays true. It now supplies actorUid/scope required by the owned journal matcher; additional cross-actor and cross-scope cases stay false. Prior auth restored in finally. No weakening of matching behavior or ignored failures.

These are setup/ownership contract repairs, not proof that all three-device scenarios pass. Focused execution still pending; diagnose any residual failure rather than altering expected money/state.
