#!/usr/bin/env python3
"""Local aggregate orchestration. Default only prints a plan; --run needs frozen source digest."""
import argparse, collections, hashlib, json, os, pathlib, re, shutil, signal, subprocess, sys, threading, time
ROOT = pathlib.Path('/workspace/Zoe-System-target')
OUT = pathlib.Path('/workspace/zoe-audit-target-20261029')
BASE = 'b0a67e915e61e6b8c8e4bc06a435c86742e45fa0'
WIP = '43ad59f00a93441fb95636e61375a19a689005be'
MEASURE = ROOT / 'ZoeW/dist-audit/measure-root'
LOOPBACK = OUT / 'node-loopback-faye.cjs'
NUMERIC = OUT / 'proposed/numeric-witness/preload.cjs'
ENV_SETUP = pathlib.Path('/workspace/zoe-cloud/env.sh')
EMU_RULES = ROOT / 'audit-tools/emu/real.rules.json'
ROOT_RULES = ROOT / 'firebase-database.rules.json'

def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()
def snapshot():
    paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'], cwd=ROOT).split(b'\0')
    files = {}
    for raw in sorted(set(paths)):
        if not raw: continue
        name = os.fsdecode(raw); p = ROOT / name
        if p.is_symlink(): files[name] = {'kind':'symlink', 'sha256':sha(os.fsencode(os.readlink(p)))}
        elif p.is_file(): files[name] = {'kind':'file', 'sha256':sha(p.read_bytes())}
        elif not p.exists(): files[name] = {'kind':'missing'}
        else: files[name] = {'kind':'other'}
    return {'head':git('rev-parse','HEAD'), 'file_count':len(files), 'files':files,
            'source_sha256':sha(json.dumps(files,sort_keys=True,separators=(',',':')).encode()),
            'base_sha':BASE,'saved_wip_sha':WIP}
def measured_inputs():
    names=['ZoeW/app.js','ZoeW/index.html','ZoeW/style.css','audit-tools/perf-check.js','audit-tools/money-multidevice-core.js','audit-tools/money-cookie-blob.js','audit-tools/supabase-money-multishop-test.js','audit-tools/supabase-fake-server.js','audit-tools/supabase-pg.js']
    files=[MEASURE/name for name in names]
    files+=list((MEASURE/'ZoeW/assets').glob('*'))+list((MEASURE/'supabase/migrations').glob('*.sql'))
    return {str(p.relative_to(MEASURE)):sha(p.read_bytes()) if p.is_file() else 'MISSING' for p in sorted(files)}

def dump(file, value):
    tmp = file.with_name(file.name + '.writing')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n'); tmp.replace(file)
def settings(label):
    browser = set()
    for p in (ROOT/'audit-tools').rglob('*.js'):
        browser.update(re.findall(r'process\.env\.([A-Z0-9_]*(?:CHROME|BROWSER))\b',p.read_text()))
    values = {name:'/usr/bin/chromium' for name in sorted(browser)}
    values.update(RUNALL_STRICT='1',CRUD_FLOW_STRICT='1',VERSIONSCOPE_STRICT='1',MONEYGUARD_STRICT='1',
        SUPABASE_STRICT='1',FBPROVISION_STRICT='1',RUNALL_JOBS='2',RUNALL_BROWSER_JOBS='1',MONEYGUARD_JOBS='2',
        ZOEWSUITE_TEST_WORKERS='2',EXITCODE_CONCURRENCY='4',VERSIONSCOPE_BASE=BASE,
        RUNALL_STATE=str(OUT/(label+'-state.tsv')),RUNALL_PROGRESS='1',ZOEW_TEST_BROWSER='/usr/bin/chromium',
        SUPABASE_DEPS_DIR=str(ROOT/'supabase/node_modules'),ZOE_NUMERIC_ROOT=str(MEASURE),
        ZOE_NUMERIC_OUTPUT_DIR=str(OUT/('numeric-'+label)),TMPDIR=str(OUT/(label+'-tmp')),
        ZOE_VERIFICATION_LOOPBACK_PRELOAD=str(LOOPBACK),ZOE_VERIFICATION_NUMERIC_PRELOAD=str(NUMERIC))
    return values
# Read only the synthetic runner temporary directory. Keep open log descriptors so unlink-at-exit cannot erase the final bytes.
class RawPreserver:
    def __init__(self,tmp,raw,root_pid):
        self.tmp,self.raw,self.root_pid=tmp,raw,root_pid; self.stop=threading.Event(); self.open={}; self.primary=set(); self.errors=[]
        self.thread=threading.Thread(target=self.watch,daemon=True)
    @staticmethod
    def parent(pid):
        try: return int(pathlib.Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[1])
        except (OSError,ValueError,IndexError): return None
    def scan(self):
        for directory in self.tmp.glob('zoe-runall.*'):
            if not directory.is_dir() or self.primary and directory.name not in self.primary: continue
            try: entries=list(directory.iterdir())
            except FileNotFoundError: continue
            for source in entries:
                if not re.fullmatch(r'\d+\.(?:out|rc|pid)',source.name): continue
                key=(directory.name,source.name)
                if source.suffix=='.pid':
                    try:
                        pid=int(source.read_text().strip())
                        if self.parent(self.parent(pid))==self.root_pid: self.primary.add(directory.name)
                    except (OSError,ValueError): pass
                if key not in self.open:
                    try: self.open[key]=os.open(source,os.O_RDONLY)
                    except OSError: continue
        for (directory,name),fd in list(self.open.items()):
            try:
                size=os.fstat(fd).st_size; target=self.raw/'runs'/directory/name; target.parent.mkdir(parents=True,exist_ok=True)
                if not target.exists() or target.stat().st_size != size:
                    chunks=[]; offset=0
                    while offset<size:
                        part=os.pread(fd,min(1024*1024,size-offset),offset)
                        if not part: break
                        chunks.append(part); offset+=len(part)
                    target.write_bytes(b''.join(chunks))
            except OSError as e: self.errors.append(type(e).__name__+':'+directory+'/'+name)
    def watch(self):
        while not self.stop.wait(.10): self.scan()
        self.scan()
    def finish(self):
        self.stop.set(); self.thread.join(timeout=20)
        if self.thread.is_alive(): self.errors.append('raw preserver did not finish within20s')
        for fd in self.open.values():
            try: os.close(fd)
            except OSError: pass
        primary=sorted(self.primary)
        if len(primary)==1:
            for p in (self.raw/'runs'/primary[0]).glob('*'):
                shutil.copyfile(p,self.raw/p.name)
        else: self.errors.append('primary runner directories identified:'+str(len(primary)))
        files={str(p.relative_to(self.raw)):sha(p.read_bytes()) for p in self.raw.rglob('*') if p.is_file()}
        return {'primary_directories':primary,'errors':sorted(set(self.errors)),'files':files,'raw_files_preserved':len(files)}

def state_summary(file):
    counts=collections.Counter(); rows=[]; malformed=[]
    if file.exists():
        for line in file.read_text().splitlines():
            if line.startswith('#'): continue
            cols=line.split('\t')
            if len(cols)<5: malformed.append(line); continue
            rows.append({'name':cols[0],'status':cols[1],'seconds':cols[2],'tree':cols[3],'summary':cols[4]}); counts[cols[1]]+=1
    return {'counts':dict(counts),'rows':rows,'malformed_rows':malformed}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label',default='verification')
    parser.add_argument('--fingerprint',action='store_true',help='Read source digest only. Does not build or execute checkers.')
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--expected-source-sha256')
    args=parser.parse_args()
    if not re.fullmatch(r'verification(?:-[a-z0-9]+)*',args.label): parser.error('label must start verification and use lowercase alphanumeric segments')
    if args.fingerprint:
        print(snapshot()['source_sha256']); return 0
    cfg=settings(args.label)
    launch='source /workspace/zoe-cloud/env.sh\nexport NODE_OPTIONS="${NODE_OPTIONS:+$NODE_OPTIONS }--require=$ZOE_VERIFICATION_LOOPBACK_PRELOAD --require=$ZOE_VERIFICATION_NUMERIC_PRELOAD"\nexec bash audit-tools/run-all.sh'
    plan={'repository':str(ROOT),'original_user_branch_sha':BASE,'saved_wip_sha':WIP,'current_head':git('rev-parse','HEAD'),
          'command':['bash','-c',launch],'settings':cfg,'budgets':'Original run-all defaults:300s generic/2400s Firebase matrix/3000s Supabase matrix; poisoned children60s; no ceiling override',
          'outputs':{'log':str(OUT/'logs'/(args.label+'-run-all.log')),'state':cfg['RUNALL_STATE'],'raw':str(OUT/('raw-'+args.label))},
          'publication':'none; this script only builds and runs local tests','requires':'Root must freeze source and refresh ignored emulator rules to match current root rules first; default invocation does not run anything.'}
    if not args.run:
        print(json.dumps(plan,ensure_ascii=False,indent=2)); return 0
    if not args.expected_source_sha256 or not re.fullmatch(r'[a-f0-9]{64}',args.expected_source_sha256): parser.error('--run requires --expected-source-sha256 from the root-approved final freeze')
    before=snapshot()
    external=[ENV_SETUP,LOOPBACK,NUMERIC,NUMERIC.with_name('observer.cjs'),pathlib.Path(__file__),EMU_RULES]
    before['orchestration_inputs']={str(p):sha(p.read_bytes()) for p in external if p.exists()}
    if before['source_sha256']!=args.expected_source_sha256: parser.error('source digest changed since root freeze; no checker was started')
    for file in [ENV_SETUP,LOOPBACK,NUMERIC,EMU_RULES,ROOT_RULES,ROOT/'ZoeW/node_modules/.bin/vitest',pathlib.Path('/usr/bin/chromium')]:
        if not file.exists(): parser.error('missing prerequisite '+str(file))
    if EMU_RULES.read_bytes()!=ROOT_RULES.read_bytes():
        parser.error('ignored emulator rules differ from current root rules; no checker was started. Root must refresh the local emulator input at freeze.')
    outfiles=[OUT/'logs'/(args.label+'-run-all.log'),OUT/(args.label+'-state.tsv'),OUT/(args.label+'-settings.json'),OUT/(args.label+'-source-before.json'),OUT/(args.label+'-source-after.json'),OUT/(args.label+'-exit.json'),OUT/('raw-'+args.label),OUT/('numeric-'+args.label),OUT/(args.label+'-tmp')]
    present=[str(p) for p in outfiles if p.exists()]
    if present: parser.error('refuse to overwrite evidence; choose a new --label: '+','.join(present))
    (OUT/'logs').mkdir(exist_ok=True); raw=OUT/('raw-'+args.label);raw.mkdir(); tmp=OUT/(args.label+'-tmp');tmp.mkdir(); pathlib.Path(cfg['ZOE_NUMERIC_OUTPUT_DIR']).mkdir()
    dump(OUT/(args.label+'-settings.json'),plan);dump(OUT/(args.label+'-source-before.json'),before)
    env=os.environ.copy()
    # Full fresh aggregate, never a resume/shard/selected-check union; leave proxy/auth environment untouched.
    for key in ['RUNALL_ONLY','RUNALL_SHARD','RUNALL_RESUME','CHECKER_TIMEOUT','ZOE_MEASURE_ONLY','ZOEWSUITE_PART','ZOEWSUITE_TEST_SHARD']:
        env.pop(key,None)
    env.update(cfg)
    started=time.monotonic();child=None; interrupted=[]
    def forward(signum,frame):
        interrupted.append(signal.Signals(signum).name)
        if child and child.poll() is None:
            try: os.killpg(child.pid,signum)
            except ProcessLookupError: pass
    old={s:signal.signal(s,forward) for s in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]}
    with outfiles[0].open('x') as log:
        child=subprocess.Popen(['bash','-c',launch],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        dump(OUT/(args.label+'-process.json'),{'pid':child.pid,'started_at':time.time(),'log':str(outfiles[0])})
        preserver=RawPreserver(tmp,raw,child.pid);preserver.thread.start()
        rc=child.wait()
        preservation=preserver.finish()
    for s,handler in old.items():signal.signal(s,handler)
    after=snapshot();after['measured_inputs']=measured_inputs();after['orchestration_inputs']={str(p):sha(p.read_bytes()) for p in external if p.exists()};dump(OUT/(args.label+'-source-after.json'),after)
    names=set(before['files'])|set(after['files']); changed=sorted(p for p in names if before['files'].get(p)!=after['files'].get(p))
    unchanged=not changed and before['head']==after['head'] and before['orchestration_inputs']==after['orchestration_inputs'];state=state_summary(OUT/(args.label+'-state.tsv'))
    summary={'checker_exit_code':rc,'elapsed_seconds':round(time.monotonic()-started,3),'head_before':before['head'],'head_after':after['head'],
             'source_before':before['source_sha256'],'source_after':after['source_sha256'],'source_unchanged':unchanged,'source_changes':changed,
             'interruptions':interrupted,'state':state,'raw_preservation':preservation,'original_user_branch_sha':BASE,'saved_wip_sha':WIP}
    # A green checker process with changed source/missing evidence is not a verified final pass.
    progress=re.findall(r'● ចប់ \[(\d+)/(\d+)\]',outfiles[0].read_text())
    expected=max((int(total) for _,total in progress),default=0)
    completed=max((int(done) for done,_ in progress),default=0)
    raw_outputs=len(list(raw.glob('[0-9]*.out')))
    complete=expected>0 and completed==expected and len(state['rows'])==expected and len({row['name'] for row in state['rows']})==expected and raw_outputs==expected and not state['malformed_rows'] and not preservation['errors']
    summary['discovery_integrity']={'expected_from_runner_progress':expected,'completed_progress':completed,'state_rows':len(state['rows']),'raw_outputs':raw_outputs,'complete':complete}
    summary['verification_status']='PASS' if rc==0 and unchanged and complete and set(state['counts'])=={'PASS'} else 'FAIL_OR_INCOMPLETE'
    dump(OUT/(args.label+'-exit.json'),summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['state','raw_preservation','source_changes']},ensure_ascii=False))
    return rc if rc>0 else (0 if summary['verification_status']=='PASS' else 1)
if __name__=='__main__':sys.exit(main())
