# Supabase functions checker type guard — environment false RED, separate guard weakness

Frozen checkout: `27f00719aa59645b1b74d083d3ac7da0019113f5`. Original aggregate evidence `raw-verification/runs/zoe-runall.RWA51g/207.out` remains **234 PASS / 1 FAIL**. Strict compilation checked all7 function files with0errors;51behavior mutations passed. This investigation does not rewrite that aggregate result or claim a new full checker pass. No tracked source, dependency, build or running aggregate process was changed.

## Reproduced cause of the current failure

`audit-tools/supabase-functions-test.js:947` tests a literal substring: `out.includes(sdkTypes)`. In this environment `target/supabase/node_modules` is a symlink to the original checkout dependencies. TypeScript resolves the SDK declaration to its physical path; the checker expects the symlink spelling.

A bounded compile-discovery-only probe (`--listFilesOnly`, no emit/typecheck/runtime) took approximately0.51s and listed7function files/110totalfiles. Expected string:

`/workspace/Zoe-System-target/supabase/node_modules/@supabase/supabase-js/dist/index.d.mts`

Actual listed file:

`/workspace/Zoe-System/supabase/node_modules/@supabase/supabase-js/dist/index.d.mts`

Both resolve to the same physical file (SHA256 `11a6410cad230333bafa6713b7d005fa0fb855b75cb585f992f698f8f676c29d`). Literal guard=false; exact canonical identity guard=true. The current failure is a checker path-identity defect exposed by this dependency environment, not an observed Edge Function code/type failure. Original application imports remain typed (`admin-deps.ts` imports/accepts `SupabaseClient`; function entrypoints import real `createClient`).

Evidence: `supabase-functions-type-path-diagnosis.json`, `logs/supabase-functions-type-path-list.log`; the retained temporary config path is recorded in JSON. The complete strict check was not rerun during this investigation; its0error result comes from the frozen aggregate.

## Separate false-green limitation of the old assertion

Merely listing the SDK declaration does not prove the imported API is not `any`. An isolated compile-only invalid API probe calls `client.auth.__zoeTypeProbeMustNotExist()`:

- Real pinned SDK declarations: compiler exit2 with exactly one expected TS2339 missing-property diagnostic (~0.59s).
- An `any` shim mapped to the import, while including the real SDK declaration as an unrelated input: compiler exit0 (~0.45s). The old path-presence guard still returns true.

This is a synthetic checker negative control, not evidence that production code currently uses an any shim. No probe JS ran and no HTTP request was made. `supabase-functions-type-meaning-controls.json` records both results and retained configs; matching raw compiler logs preserve the diagnostics.

## Unapplied focused proposal

`supabase-functions-type-guard-proposal.patch` and `proposed/supabase-functions-type-guard.js` are external only. They retain the original strict compile/file-count assertion; match complete `--listFiles` lines using filesystem canonical identity rather than a substring; label that check accurately as SDK declaration discovery; and add an intentional invalid-API compile control that must fail solely with the expected missing-property error. An any shim then fails this guard because its invalid-API compile unexpectedly succeeds. Temporary files are cleaned in `finally`.

Seven pure canonical-identity controls pass, including actual output and both symlink/canonical spellings; empty discovery, diagnostic-text mentions, different declarations and suffix decoys remain rejected. See `supabase-functions-type-path-guard-controls.json`. Proposed JS passes `node --check`. Its full checker execution is **NOT RUN** while the aggregate remains frozen.

An environment-only confirmation after resource release can select the already-existing canonical dependency directory, without changing package versions or weakening checks:

```sh
cd /workspace/Zoe-System-target/ZoeW/dist-audit/measure-root
SUPABASE_STRICT=1 ZOE_REPO_ROOT=/workspace/Zoe-System-target \
SUPABASE_DEPS_DIR=/workspace/Zoe-System/supabase/node_modules \
node audit-tools/supabase-functions-test.js
```

That proposed rerun is not yet executed. It should resolve the literal-path false RED but does not by itself strengthen the old any-proof claim; the intentional-invalid-API control addresses that separate checker weakness. No automatic exemption, skip or global guard relaxation is proposed.
