# ផែនការ verification និង load — មិនទាន់រត់

Original user branch `b0a67e915e61e6b8c8e4bc06a435c86742e45fa0`; saved WIP `43ad59f00a93441fb95636e61375a19a689005be`។ Final run កត់ HEAD និង digest ពិតម្ដងទៀត។ Root ត្រូវ freeze source និង docs ជាមុន។ កុំសរសេរ source ឬ rebuild measure-root កំឡុង aggregate/performance។ Initial `final-*` / `raw-final` / 208PASS7FAIL រក្សាដដែល។

## Aggregate ថ្មីមួយពេញ

```sh
ZOE_VERIFICATION_SHA="$(python3 /workspace/zoe-audit-target-20261029/run-verification.py --fingerprint)"
python3 /workspace/zoe-audit-target-20261029/run-verification.py --run --expected-source-sha256 "$ZOE_VERIFICATION_SHA"
```

Default invocation គ្រាន់តែបង្ហាញ plan។ `--run` ទាមទារ digest; បើ source ប្ដូរ មិនចាប់ផ្ដើម។ Existing output ត្រូវបដិសេធ; rerunថ្មីប្រើ `--label verification-2` និងរក្សា evidenceជុំមុន។ Environment source រួចទើប append loopback/numeric preloads; proxy/auth variables មិនត្រូវបោះចោល។ Freshfull aggregate គ្មាន resume/only/shard; original ceilings 300s/2400s/3000s និង poisoned-child60s រក្សាដដែល; jobs2/browser1។

Outputs: `verification-settings.json`, `verification-source-before.json`, `verification-source-after.json`, `verification-state.tsv`, `verification-exit.json`, `logs/verification-run-all.log`, `raw-verification`, `numeric-verification`។ Raw observerរក្សា file descriptors ដូច្នេះការលុប temp logs នៅចុង runner មិនបាត់ bytesចុងក្រោយ។ Selfcheck4PASS គ្រាន់តែ synthetic raw-unlink/state test មិនមែន app regression។ Final PASS ទាមទារ checkerexit0 + source/HEAD/externalpreloadsដដែល + runnerprogress totals = unique state rows = preserved raw outputs + allPASS។

## Performance និង multi-shop — បន្ទាប់ពី aggregate

តេស្តមាន source/build guard ដាច់។ មិនទាមទារ aggregatePASS ដើម្បីវាស់ diagnostic workload ប៉ុន្តែត្រូវរាយ aggregate failures ជាមួយ measurements។

```sh
python3 /workspace/zoe-audit-target-20261029/verify-load-readiness.py verification
source /workspace/zoe-cloud/env.sh
export NODE_OPTIONS="${NODE_OPTIONS:+$NODE_OPTIONS }--require=/workspace/zoe-audit-target-20261029/node-loopback-faye.cjs --require=/workspace/zoe-audit-target-20261029/proposed/numeric-witness/preload.cjs"
export NODE_PATH=/workspace/Zoe-System-target/ZoeW/node_modules
export ZOE_REPO_ROOT=/workspace/Zoe-System-target
export ZOE_MEASURE_ROOT=/workspace/Zoe-System-target/ZoeW/dist-audit/measure-root
export ZOE_NUMERIC_ROOT="$ZOE_MEASURE_ROOT"
export SUPABASE_DEPS_DIR=/workspace/Zoe-System-target/supabase/node_modules
```

ជំហាន history/trash: 1200 → 5000 → 10000 orders និង trashចំនួនដូចគ្នា; original seed 1/2/3barcodes តាមrow; 50samples ក្នុងមួយ operation; Chromium412×780។ រត់មួយចប់ទើបបន្ទាប់; រក្សា exit code និង rawlog។

```sh
PERF_ORDERS=1200 PERF_CHROME=/usr/bin/chromium PERF_APP_DIR="$ZOE_MEASURE_ROOT" timeout -k 10 300 node /workspace/zoe-audit-target-20261029/perf-distribution.cjs > /workspace/zoe-audit-target-20261029/logs/verification-perf-1200.log 2>&1
PERF_ORDERS=5000 PERF_CHROME=/usr/bin/chromium PERF_APP_DIR="$ZOE_MEASURE_ROOT" timeout -k 10 300 node /workspace/zoe-audit-target-20261029/perf-distribution.cjs > /workspace/zoe-audit-target-20261029/logs/verification-perf-5000.log 2>&1
PERF_ORDERS=10000 PERF_CHROME=/usr/bin/chromium PERF_APP_DIR="$ZOE_MEASURE_ROOT" timeout -k 10 300 node /workspace/zoe-audit-target-20261029/perf-distribution.cjs > /workspace/zoe-audit-target-20261029/logs/verification-perf-10000.log 2>&1
```

`AUDIT_METRICS` មាន rawsample,p50,p95,p99,max និង CDP before/after (heap,listener,CPU TaskDuration)។ Singlebrowser/syntheticSDK មិនមែន backendlatency។ `listenerRepaint` ដើមវាស់ synchronous snapshot/flush មិន await entire debounced background cycle; កុំដាក់ឈ្មោះថា fullsyncconvergence។ Rate assertionsដើមនៅដដែល (`PERF_REPORT` មិនបើក)។

ជំហាន Supabase 4shops×3devices → 8shops×3devices; `SBMONEY_OPS=6`, seed0; realPostgres+adapter/browser និង syntheticAuth/ZTO/Realtime transport។ Numericwitness output ដាច់រាល់ជំហាន។ Original3000s ceiling មិនលើក។

```sh
ZOE_NUMERIC_OUTPUT_DIR=/workspace/zoe-audit-target-20261029/numeric-verification-scale4 SBMONEY_SHOPS=4 SBMONEY_DEVICES=3 SBMONEY_OPS=6 SBMONEY_RUN0=0 SBMONEY_STRICT=1 SBMONEY_CHROME=/usr/bin/chromium SBMONEY_APP_DIR="$ZOE_MEASURE_ROOT" timeout -k 10 3000 node "$ZOE_MEASURE_ROOT/audit-tools/supabase-money-multishop-test.js" > /workspace/zoe-audit-target-20261029/logs/verification-scale4.log 2>&1
ZOE_NUMERIC_OUTPUT_DIR=/workspace/zoe-audit-target-20261029/numeric-verification-scale8 SBMONEY_SHOPS=8 SBMONEY_DEVICES=3 SBMONEY_OPS=6 SBMONEY_RUN0=0 SBMONEY_STRICT=1 SBMONEY_CHROME=/usr/bin/chromium SBMONEY_APP_DIR="$ZOE_MEASURE_ROOT" timeout -k 10 3000 node "$ZOE_MEASURE_ROOT/audit-tools/supabase-money-multishop-test.js" > /workspace/zoe-audit-target-20261029/logs/verification-scale8.log 2>&1
python3 /workspace/zoe-audit-target-20261029/proposed/numeric-witness/analyze.py /workspace/zoe-audit-target-20261029/numeric-verification
python3 /workspace/zoe-audit-target-20261029/proposed/numeric-witness/analyze.py /workspace/zoe-audit-target-20261029/numeric-verification-scale4
python3 /workspace/zoe-audit-target-20261029/proposed/numeric-witness/analyze.py /workspace/zoe-audit-target-20261029/numeric-verification-scale8
```

Deterministic Sheet/Cookie/Palm faultmatrix រត់ shop0; seeded concurrent rounds រត់គ្រប់shop និង neighbor-isolation reads។ មិនអះអាងថា fullmatrix រត់នៅគ្រប់shopទេ។ Matrixelapsed រួម observerJSON/I/O overhead; មិនមែន p95RPC latency ឬ productioncapacity។ Capture per-stage walltime separately; rawlog មាន reads/writes/convergence ដែលcheckerបានវាស់ប៉ុណ្ណោះ។

## Pending evidence queue workload ផ្សេង

Probe `pending-evidence-perf.cjs` ត្រៀមរួច និង syntax-check PASS; **NOT RUN** រង់ចាំ final aggregate/fresh build។ វាប្រើ server/seed/SDK helpers ពី frozen `perf-check.js` ដដែល និង actual Chromium localStorage + exported real journal/warning functions។

Workload: 0→50→100→200 requested pending records, phases prepared→claim-pending→claimed→save-pending→pending; 1200 history orders; 50 list/warning samples, 20 listener samples, 20 reload-to-rendered-readiness samples ក្នុងមួយ workload។ បើ512KiB capបញ្ឈប់មុន200 ត្រូវកត់ actual pending count និង phase/error ពិត មិនរាប់ថាបានសាក200ទេ។ Storage read/listener work ត្រូវរក្សា pending bytesដដែល។

```sh
ZOE_VERIFICATION_LABEL=verification PERF_APP_DIR="$ZOE_MEASURE_ROOT" PENDING_PERF_ORDERS=1200 timeout -k 10 300 node /workspace/zoe-audit-target-20261029/pending-evidence-perf.cjs > /workspace/zoe-audit-target-20261029/logs/verification-pending-perf.log 2>&1
```

Output `verification-pending-perf.json` រក្សា partial workload លើរាល់ដំណាក់កាល។ Default refuses overwrite; source/build guard ប្រើ final aggregate source-after hashes។ វាស់ listener ពី `__fireHistory()` រហូត actual `historyRenderSeq` ប្ដូរ និង2 animation frames៖ រួម120ms debounce និង synchronous journal warning/render, មិនមែន completionរបស់ async cleanup ឬ full backend convergence។ Readiness ជា reload→actual authenticated scope+history rendered, មិនមែន guarantee all network jobs complete។ p99 នៃ20samples ជា maximum observed និងមិនមាន statistical precisionខ្ពស់។ 200pending/512KiB ជាដែនកំណត់ មិនមែន production capacity guarantee; no speculative optimization។
