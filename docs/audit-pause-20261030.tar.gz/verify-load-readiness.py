import importlib.util,json,pathlib,sys
root=pathlib.Path('/workspace/zoe-audit-target-20261029');label=sys.argv[1] if len(sys.argv)>1 else 'verification'
spec=importlib.util.spec_from_file_location('verification',root/'run-verification.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
saved=json.loads((root/(label+'-source-after.json')).read_text());verdict=json.loads((root/(label+'-exit.json')).read_text())
now=m.snapshot();same=now['source_sha256']==saved['source_sha256'] and now['head']==saved['head'];built=m.measured_inputs()==saved.get('measured_inputs')
assert verdict['source_unchanged'] and same and built,'source/build changed after aggregate: no load test started; coordinate fresh build'
assert all(v!='MISSING' for v in m.measured_inputs().values()),'required measurement inputs missing'
metadata=json.loads((root/'perf-instrumentation.json').read_text())
assert m.sha((m.ROOT/'audit-tools/perf-check.js').read_bytes())==metadata['source_sha256'],'perf instrumentation must be rederived from changed checker'
print(json.dumps({'head':now['head'],'source_sha256':now['source_sha256'],'measure_matches_aggregate':True,'aggregate_verdict':verdict['verification_status']}))
